# Release verification — 2026-10-14

The core snapshot includes 292 server/source/runtime/dispatcher files copied byte-for-byte from the previously used standalone installation. The generated dispatcher also matches the deployed standalone Documents dispatcher. BUILD-PROVENANCE.json records hashes.

The bundled Node.js v24.15.0 Windows x64 archive matches the official nodejs.org SHA-256 release list, and its node.exe matches the runtime previously used here. Installed dependencies were copied without an npm update. All licenses remain bundled.

Offline MCP checks passed in both editing and read-only modes: 8 tools / 197 operations in normal mode, 7 tools / 43 operations in read-only mode. Checks cover initialization, tools/list, category schemas, unknown-operation rejection, disabled arbitrary eval and rejection of a mutation in read-only mode. No AE application was launched for those checks.

58 upstream tests passed across launcher, capability policy, batch validation, JSX lint, JSON escaping and argument validation. PowerShell entry points passed parsing checks.

Installer validation passed against a separate simulated Windows work profile, including configuration backup/preservation, paths with spaces and an apostrophe, repeat installation, source rebuild, conflicting-registration refusal and detection of a tampered file. All 292 installed core files retained their original hashes, including the root package.json. Evidence is recorded in evidence/package-validation.json. The release ZIP is also checked against every manifest entry.

After Effects was closed during packaging. No fresh live AE readback, composition creation, punch, save, render or work-computer test was performed. The work computer must pass Test-Connection.ps1 -Live and read-only calls through the newly loaded Codex MCP before its first job. The successful prior title/punch work is historical evidence, not a work-machine acceptance result.
