# Provenance and redistribution

The standalone server is a locally modified copy of `kumoproductions/mcp-aftereffects`, upstream version 0.2.0, originally obtained at commit 11f6ca4. The MIT license and attribution are preserved in LICENSE and upstream/LICENSE. This is a frozen snapshot of the actual local standalone installation, not a newly downloaded vendor version.

Local changes include the independent kerry-after-effects-mcp mailbox, deployed standalone dispatcher, eight-tool surface, shorter tool instructions, stop-on-connection-failure guidance, read-only version inspection and 15-second default bridge timeout. Package-only additions provide Windows installation, integrity checking, tests and operational handoff instructions. Core server, source, compiled runtime and dispatcher are copied byte-for-byte; BUILD-PROVENANCE.json records their snapshot hashes.

This archive contains no Higgsfield/FNF creative skill corpus, vendor launcher, vendor account configuration, or runtime dependency on the installed Higgsfield bridge. The standalone runtime uses the MIT upstream implementation. Dependencies retain their own licenses in their installed package directories; DEPENDENCIES.json inventories installed packages and declared license fields.

Node.js v24.15.0 for Windows x64 is bundled from the official nodejs.org release archive. Its archive was checked against nodejs.org's SHASUMS256.txt. The full Node distribution, LICENSE, and bundled third-party notices are retained under runtime/. The release checksum list is in evidence/node-SHASUMS256.txt. Use remains subject to each component's license; Adobe After Effects is separately installed/licensed and is not included.

No personal Codex configuration, auth.json, API keys, LM Studio chats, private campaign media, AEPs, or previous mailbox traffic are included. Workflow instructions and the organization skill describe production procedures, not completed installation or live validation on the work computer.
