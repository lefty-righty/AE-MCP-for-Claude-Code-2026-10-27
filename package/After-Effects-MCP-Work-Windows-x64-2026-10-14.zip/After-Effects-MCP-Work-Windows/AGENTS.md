# Standalone AE MCP work package

Read START-HERE.md before installation. Read WORKFLOW.md before any AE production task. Use this package's after-effects-local registration and its standalone dispatcher. Do not route this package's validation through Higgsfield or an unrelated AE bridge.

Use the bundled skills/after-effects-project-organize/SKILL.md for Project-panel organization. Preserve Assets / Comps / Solids and each imported AEP's internal hierarchy under Assets/AEPs. Do not reorganize an existing campaign or move source media without the user's task-specific authorization.

Discover exact operation schemas via ae_catalog. Inspect before editing, preserve the original AEP, and verify actual changes in AE. Stop after an uncertain timeout and inspect completion before retrying. Installation permits only the installation and read-only checks described in WORK-CODEX-INSTALL-PROMPT.txt; a creative job needs its own brief. No rendering or client delivery is implied by installation.
