# After Effects MCP — Windows work installation

This is the standalone local MCP used by the earlier title-sequence and dealership punch scripts. It includes its own dispatcher, compiled server, complete source, locked installed dependencies, a Windows x64 Node.js runtime, organization skill, installer, and verification tools. No Higgsfield login, plugin, CLI, LM Studio, or Qwen installation is required.

## Install with work Codex

1. Copy the ZIP to the work computer and extract the entire archive to a local folder.
2. Open the extracted folder as a local Codex project, or give work Codex that folder's full path.
3. Paste the complete text from `WORK-CODEX-INSTALL-PROMPT.txt` into work Codex.
4. Restart Codex after registration, or start a fresh session that loads the new MCP.
5. Open After Effects yourself and finish any dialogs. Enable **Edit > Preferences > Scripting & Expressions > Allow Scripts to Write Files and Access Network**. Run the read-only live check described below.

Default permanent installation: `%LOCALAPPDATA%\CodexIntegrations\AfterEffectsMCP`.
Dispatcher: the current user's Windows Documents folder, under `CodexIntegrations\StandaloneAE\dispatcher.jsx`.
Codex configuration: `%CODEX_HOME%\config.toml`, if CODEX_HOME is set, otherwise `%USERPROFILE%\.codex\config.toml`.
Registration name: `after-effects-local`.

The installer backs up an existing Codex configuration, adds only its managed MCP block, preserves unrelated settings, and stops rather than replacing an existing unmanaged entry with the same name. It preserves an existing organization skill if different. It does not install into Adobe's application directories or require administrator privileges. Use the same Windows account and elevation level for Codex and AE.

## Manual installation

From the extracted package folder, in Windows PowerShell:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Install.ps1
```

For an unusual AE location:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Install.ps1 -AfterEffectsExe 'D:\Adobe\Adobe After Effects 2026\Support Files\AfterFX.exe'
```

Optional parameters: `-InstallRoot`, `-CodexHome`, `-DispatcherDirectory`, `-SkipRegistration`, and `-ReadOnly`. Paths must be absolute. Use a permanent local installation directory; extraction on a network drive is not the final runtime location.

After installing, run from the permanent installed folder:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Test-Connection.ps1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Test-Connection.ps1 -Live
```

The first test checks MCP initialization, tool schemas, catalogs and rejection policies without launching AE. The second requires an already-running AE, forces read-only mode, reads AE version/project information, and compares project path, item count and dirty state. It creates no composition, changes no content, saves no AEP and renders nothing. Reports go to the installed `logs` folder. A successful offline test alone does not establish AE control.

In a fresh work Codex chat, also ask it to call `ae_version_info`, `ae_project_info`, and `ae_catalog` on **after-effects-local**, and report the returned data. This separately proves that the work Codex host is connected. If it cannot see the MCP, restart Codex and inspect the generated configuration; do not repeatedly retry a failing AE call.

## What remains machine-dependent

- Adobe After Effects must already be installed and licensed. The local runtime was tested with AE 2026; other versions require their own live check.
- Install the campaign's required fonts and effects, provide linked media, and resolve missing assets before comparing creative results.
- The connector runs locally without an account or network service. Codex uses its own work account/model access normally. This ZIP contains no account credentials.
- Eight top-level tools expose the operation catalog on demand. Arbitrary `eval.run` remains disabled; the previous punch used the declared operations.
- The MCP exposes editing and render controls. `WORKFLOW.md` supplies the operating procedure. It is not an automatic dealership application that independently understands every campaign.
- The original AEP, dealership assets, voiceovers and prior case-specific scripts are not integration dependencies and are not bundled. Use work job assets and fresh item IDs.
- ProRes availability and render templates belong to the work AE installation. Rendering and delivery are separate job steps; the successful punch test did not establish automated ProRes delivery verification.

Read `WORKFLOW.md`, `EXTERNAL-TOOLS.md`, `TROUBLESHOOTING.md`, `NOTICE.md`, and `VERIFICATION.md` before production tests. `Verify-Integrity.ps1` checks all shipped files against the snapshot manifest.

## Recovery

The install report is `installation.json`; it records the actual AE path, dispatcher, Codex configuration and backup. To disable this MCP, set `enabled = false` in its `[mcp_servers.after-effects-local]` table, or remove just the marked installer block, then restart Codex. Retain unrelated MCP entries. Configuration backups contain the work machine's prior settings and should remain private on that computer.

`Rebuild.ps1` is for deliberate development after reviewing source. It uses the bundled compiler without downloading packages and does not deploy to the live Documents dispatcher. Source changes invalidate the release hash manifest; reinstall the original ZIP to restore the frozen release. Do not run `npm update` to install this package.

Official Codex MCP reference: https://learn.chatgpt.com/docs/extend/mcp?surface=cli
