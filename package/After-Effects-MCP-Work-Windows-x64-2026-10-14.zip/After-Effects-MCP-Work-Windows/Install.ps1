[CmdletBinding()]
param(
    [string]$InstallRoot,
    [string]$CodexHome,
    [string]$AfterEffectsExe,
    [string]$DispatcherDirectory,
    [switch]$SkipRegistration,
    [switch]$ReadOnly
)
$ErrorActionPreference = 'Stop'
$node = Join-Path $PSScriptRoot 'runtime\node.exe'
if (!(Test-Path -LiteralPath $node -PathType Leaf)) { throw 'Extract the entire ZIP before running Install.ps1. The bundled runtime is missing.' }
$installArgs = @((Join-Path $PSScriptRoot 'scripts\install.mjs'))
foreach ($setting in @(@('--install-root', $InstallRoot), @('--codex-home', $CodexHome), @('--ae-exe', $AfterEffectsExe), @('--dispatcher-dir', $DispatcherDirectory))) {
    if ($setting[1]) { $installArgs += $setting }
}
if ($SkipRegistration) { $installArgs += '--skip-register' }
if ($ReadOnly) { $installArgs += '--read-only' }
& $node @installArgs
if ($LASTEXITCODE -ne 0) { throw "Installation failed (exit $LASTEXITCODE). Read the error above; do not keep retrying." }
