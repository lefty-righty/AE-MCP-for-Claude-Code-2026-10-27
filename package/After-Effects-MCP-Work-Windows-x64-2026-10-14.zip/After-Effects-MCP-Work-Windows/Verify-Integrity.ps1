$ErrorActionPreference = 'Stop'
& (Join-Path $PSScriptRoot 'runtime\node.exe') (Join-Path $PSScriptRoot 'scripts\integrity.mjs')
if ($LASTEXITCODE -ne 0) { throw 'Package integrity check failed.' }
