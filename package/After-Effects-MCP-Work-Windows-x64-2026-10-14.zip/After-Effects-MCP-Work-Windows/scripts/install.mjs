import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync, execFileSync} from 'node:child_process';
import {root, verifyIntegrity} from './integrity.mjs';

const args = process.argv.slice(2);
function option(name, fallback) {
  const i = args.indexOf(name);
  if (i < 0) return fallback;
  if (!args[i + 1] || args[i + 1].startsWith('--')) throw Error('Missing value for ' + name);
  return path.resolve(args[i + 1]);
}
const slash = p => p.replaceAll('\\', '/');
const hash = p => crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const stamp = new Date().toISOString().replace(/[:.]/g, '-');
const productId = 'standalone-after-effects-mcp-work-windows';
const begin = '# BEGIN STANDALONE AFTER EFFECTS MCP - managed by its installer';
const end = '# END STANDALONE AFTER EFFECTS MCP';
const id = 'after-effects-local';

function findAfterEffects(explicit) {
  if (explicit) {
    if (!fs.existsSync(explicit) || path.basename(explicit).toLowerCase() !== 'afterfx.exe') throw Error('--ae-exe must name an existing AfterFX.exe');
    return explicit;
  }
  const candidates = [];
  if (process.env.AE_MCP_EXE) candidates.push(process.env.AE_MCP_EXE);
  const adobe = path.join(process.env.ProgramFiles || 'C:/Program Files', 'Adobe');
  if (fs.existsSync(adobe)) {
    const names = fs.readdirSync(adobe).filter(n => /^Adobe After Effects \d/.test(n) && !/beta/i.test(n)).sort().reverse();
    for (const name of names) candidates.push(path.join(adobe, name, 'Support Files', 'AfterFX.exe'));
  }
  const found = candidates.find(p => fs.existsSync(p) && path.basename(p).toLowerCase() === 'afterfx.exe');
  if (!found) throw Error('After Effects was not found. Rerun Install.ps1 -AfterEffectsExe "C:\\path\\to\\Support Files\\AfterFX.exe". No Codex settings have been changed.');
  return path.resolve(found);
}

try {
  if (process.platform !== 'win32' || process.arch !== 'x64') throw Error('This package is for Windows x64.');
  const manifest = verifyIntegrity();
  const installRoot = option('--install-root', path.join(process.env.LOCALAPPDATA || path.join(os.homedir(), 'AppData', 'Local'), 'CodexIntegrations', 'AfterEffectsMCP'));
  const codexHome = option('--codex-home', process.env.CODEX_HOME || path.join(os.homedir(), '.codex'));
  const aeExe = findAfterEffects(option('--ae-exe'));
  const documents = execFileSync('powershell.exe', ['-NoProfile', '-Command', '[Environment]::GetFolderPath("MyDocuments")'], {encoding: 'utf8', windowsHide: true}).trim() || path.join(os.homedir(), 'Documents');
  const dispatcherDir = option('--dispatcher-dir', path.join(documents, 'CodexIntegrations', 'StandaloneAE'));
  const dispatcher = path.join(dispatcherDir, 'dispatcher.jsx');
  const register = !args.includes('--skip-register');
  const configPath = path.join(codexHome, 'config.toml');
  const oldConfig = fs.existsSync(configPath) ? fs.readFileSync(configPath, 'utf8') : '';
  const marked = oldConfig.includes(begin) && oldConfig.includes(end);
  if (oldConfig.includes(begin) !== oldConfig.includes(end)) throw Error('Incomplete managed config markers. Have Codex inspect config.toml before installation.');
  const withoutManaged = marked ? oldConfig.slice(0, oldConfig.indexOf(begin)) + oldConfig.slice(oldConfig.indexOf(end) + end.length) : oldConfig;
  if (register && /^\s*\[mcp_servers\.(?:after-effects-local|"after-effects-local"|'after-effects-local')(?:\.|\])/m.test(withoutManaged)) {
    throw Error('An existing unmanaged after-effects-local registration is present. No configuration was changed. Have work Codex compare it with config.generated.toml; do not replace unrelated settings.');
  }
  if (path.resolve(installRoot) === path.parse(installRoot).root || [os.homedir(), codexHome, path.dirname(aeExe)].some(p => path.resolve(p).toLowerCase() === installRoot.toLowerCase())) {
    throw Error('Choose a dedicated MCP installation folder.');
  }
  if (installRoot.toLowerCase() !== root.toLowerCase() && fs.existsSync(installRoot) && fs.readdirSync(installRoot).length) {
    const marker = path.join(installRoot, 'BUNDLE-INFO.json');
    if (!fs.existsSync(marker) || JSON.parse(fs.readFileSync(marker, 'utf8')).id !== productId) throw Error('Installation folder is nonempty and is not this MCP. Choose another --install-root.');
  }
  fs.mkdirSync(installRoot, {recursive: true});
  const installedBackup = path.join(installRoot, 'install-backups', stamp);
  if (installRoot.toLowerCase() !== root.toLowerCase()) {
    for (const entry of [...manifest.files, {path: 'SHA256-MANIFEST.json', sha256: hash(path.join(root, 'SHA256-MANIFEST.json'))}]) {
      const src = path.join(root, entry.path), dst = path.join(installRoot, entry.path);
      if (fs.existsSync(dst)) {
        if (hash(dst) === entry.sha256) continue;
        const backup = path.join(installedBackup, entry.path);
        fs.mkdirSync(path.dirname(backup), {recursive: true}); fs.copyFileSync(dst, backup);
      }
      fs.mkdirSync(path.dirname(dst), {recursive: true}); fs.copyFileSync(src, dst);
    }
  }
  verifyIntegrity(installRoot);
  fs.mkdirSync(path.join(installRoot, 'logs'), {recursive: true});
  fs.mkdirSync(dispatcherDir, {recursive: true});
  const srcDispatcher = path.join(installRoot, 'dispatcher.jsx');
  if (fs.existsSync(dispatcher) && hash(dispatcher) !== hash(srcDispatcher)) fs.copyFileSync(dispatcher, dispatcher + '.before-' + stamp);
  if (path.resolve(srcDispatcher).toLowerCase() !== path.resolve(dispatcher).toLowerCase()) fs.copyFileSync(srcDispatcher, dispatcher);
  const node = path.join(installRoot, 'runtime', 'node.exe');
  const server = path.join(installRoot, 'server.mjs');
  const report = path.join(installRoot, 'logs', 'installation-offline.json');
  const environment = {...process.env, AE_MCP_EXE: aeExe, AE_MCP_DISPATCHER: dispatcher};
  const checked = spawnSync(node, [path.join(installRoot, 'tests', 'verify-portable.mjs'), '--report', report], {cwd: installRoot, env: environment, stdio: 'inherit', windowsHide: true});
  if (checked.status !== 0) throw Error('Offline protocol check failed. Codex configuration has not been changed.');
  const readOnly = args.includes('--read-only');
  const config = `${begin}\n[mcp_servers.${id}]\ncommand = ${JSON.stringify(slash(node))}\nargs = [${JSON.stringify(slash(server))}]\ncwd = ${JSON.stringify(slash(installRoot))}\nstartup_timeout_sec = 30\ntool_timeout_sec = 900\n\n[mcp_servers.${id}.env]\nAE_MCP_EXE = ${JSON.stringify(slash(aeExe))}\nAE_MCP_DISPATCHER = ${JSON.stringify(slash(dispatcher))}\nAE_MCP_READONLY = ${JSON.stringify(readOnly ? '1' : '0')}\nAE_MCP_ENABLE_EVAL = "0"\nAE_MCP_ALLOW_CATEGORIES = ""\nAE_MCP_RUNTIME_DIR = ""\n${end}`;
  fs.writeFileSync(path.join(installRoot, 'config.generated.toml'), config + '\n');
  let configBackup = null;
  if (register) {
    fs.mkdirSync(codexHome, {recursive: true});
    const newConfig = marked ? oldConfig.slice(0, oldConfig.indexOf(begin)) + config + oldConfig.slice(oldConfig.indexOf(end) + end.length) : oldConfig + (oldConfig.endsWith('\n') ? '\n' : '\n\n') + config + '\n';
    if (fs.existsSync(configPath)) { configBackup = configPath + '.before-after-effects-mcp-' + stamp; fs.copyFileSync(configPath, configBackup); }
    const temporary = configPath + '.after-effects-mcp.tmp';
    fs.writeFileSync(temporary, newConfig, {flag: 'wx'});
    fs.renameSync(temporary, configPath);
  }
  const skillSource = path.join(installRoot, 'skills', 'after-effects-project-organize');
  const skillTarget = path.join(codexHome, 'skills', 'after-effects-project-organize');
  let skillStatus = 'not registered';
  if (register) {
    if (fs.existsSync(path.join(skillTarget, 'SKILL.md'))) {
      skillStatus = hash(path.join(skillSource, 'SKILL.md')) === hash(path.join(skillTarget, 'SKILL.md')) ? 'already identical' : 'existing skill preserved; compare bundled copy before any replacement';
    } else { fs.mkdirSync(skillTarget, {recursive: true}); fs.copyFileSync(path.join(skillSource, 'SKILL.md'), path.join(skillTarget, 'SKILL.md')); skillStatus = 'installed'; }
  }
  const installation = {id: productId, installedAt: new Date().toISOString(), installRoot, afterEffectsExe: aeExe, dispatcher, configPath: register ? configPath : null, configBackup, readOnly, skillStatus, offlineVerified: true, liveVerified: false};
  fs.writeFileSync(path.join(installRoot, 'installation.json'), JSON.stringify(installation, null, 2));
  console.log(JSON.stringify({ok: true, ...installation}, null, 2));
  console.log('Restart Codex or start a fresh session to load this MCP. Open After Effects, enable its scripting file/network access, then run Test-Connection.ps1 -Live from the installed folder. Installation has not edited any AE project.');
} catch (error) { console.error('INSTALL FAILED: ' + error.message); process.exitCode = 1; }
