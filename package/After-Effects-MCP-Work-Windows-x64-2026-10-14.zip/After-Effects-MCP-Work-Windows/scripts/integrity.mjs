import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
export const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export function verifyIntegrity(base = root) {
  const manifest = JSON.parse(fs.readFileSync(path.join(base, 'SHA256-MANIFEST.json'), 'utf8'));
  const errors = [];
  for (const entry of manifest.files) {
    const target = path.resolve(base, entry.path);
    const relative = path.relative(base, target);
    if (!relative || relative.startsWith('..') || path.isAbsolute(relative)) throw Error('Unsafe manifest path');
    try {
      if (fs.lstatSync(target).isSymbolicLink()) throw Error('Symlink is not allowed');
      const hash = crypto.createHash('sha256').update(fs.readFileSync(target)).digest('hex');
      if (hash !== entry.sha256) errors.push(entry.path);
    } catch { errors.push(entry.path); }
  }
  if (errors.length) throw Error('Missing or changed package files: ' + errors.slice(0, 15).join(', '));
  return manifest;
}
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try { const m = verifyIntegrity(); console.log(JSON.stringify({ok: true, checkedFiles: m.files.length})); }
  catch (error) { console.error(error.message); process.exitCode = 1; }
}
