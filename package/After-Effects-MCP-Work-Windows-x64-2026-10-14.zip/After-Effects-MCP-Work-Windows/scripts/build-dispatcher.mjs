import os from 'node:os';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const jsx=path.join(root,'upstream','jsx');
let source=readFileSync(path.join(jsx,'dispatcher.jsx'),'utf8').replaceAll('/mcp-aftereffects','/kerry-after-effects-mcp');
source=source.replace(/^#include "([^"]+)"/gm,(_,name)=>readFileSync(path.join(jsx,name),'utf8'));
if(/^#include /m.test(source))throw Error('Unresolved JSX include');
writeFileSync(path.join(root,'dispatcher.jsx'),source);
console.log('Built standalone dispatcher.');

const deployed=path.join(os.homedir(),"Documents","CodexIntegrations","StandaloneAE");
mkdirSync(deployed,{recursive:true});
writeFileSync(path.join(deployed,"dispatcher.jsx"),source);
console.log("Deployed standalone dispatcher to " + deployed);
