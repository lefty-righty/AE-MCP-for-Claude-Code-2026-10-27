[CmdletBinding()]
param([switch]$Live)
$ErrorActionPreference = 'Stop'
$node = Join-Path $PSScriptRoot 'runtime\node.exe'
$verifyArgs = @((Join-Path $PSScriptRoot 'tests\verify-portable.mjs'))
$settingsPath = Join-Path $PSScriptRoot 'installation.json'
if (Test-Path -LiteralPath $settingsPath) {
    $settings = Get-Content -LiteralPath $settingsPath -Raw | ConvertFrom-Json
    $env:AE_MCP_EXE = $settings.afterEffectsExe
    $env:AE_MCP_DISPATCHER = $settings.dispatcher
}
if ($Live) { $verifyArgs += '--live' }
& $node @verifyArgs
if ($LASTEXITCODE -ne 0) { throw 'Verification failed. Inspect the returned error and logs before retrying.' }
