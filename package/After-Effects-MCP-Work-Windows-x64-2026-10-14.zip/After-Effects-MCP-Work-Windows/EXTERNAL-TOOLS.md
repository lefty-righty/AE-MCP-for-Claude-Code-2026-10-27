# Tools outside the MCP

The ZIP contains all server, dispatcher, JavaScript dependency and Node runtime files needed for the local AE connection. It does not copy the personal workstation's other applications or account environments.

- **After Effects and campaign resources:** install/license AE separately and supply the campaign's fonts, effects and source media. The installer discovers the work machine's AE executable; none of these resources is downloaded by the MCP.
- **VO speech timing:** the earlier punch used word/segment timestamps produced by a separate Hermes-local Whisper helper. Audio import and timeline editing are MCP operations; speech transcription is not. For similar automatic timing analysis at work, identify an existing work-approved transcriber or supply cue/word timestamps with the audio. Setting up a new transcription runtime/model is a separate task. Do not copy personal Hermes configurations or silently call a paid transcription service. Check transcribed prices against the approved script: transcription can misread dollar amounts.
- **Script documents and output verification:** work Codex needs its own way to read the supplied script format. External media inspection tools may be useful for validating final renders; they are separate from AE's render queue. The installer does not install Word/Python/FFmpeg or claim those are available.
- **Video reference analysis:** the earlier watch/video-analysis workflow is a separate capability. It is not required for MCP connectivity or an offer replacement.
- **AI model:** the MCP does not include or depend on Qwen, GPT, or another model. Use the work Codex's configured model. Consistent tools do not guarantee identical model decisions; verify the edit itself.

During first-job preflight, report which optional capabilities are available and which are needed for that job. Basic AE connection/editing does not depend on having every optional helper.
