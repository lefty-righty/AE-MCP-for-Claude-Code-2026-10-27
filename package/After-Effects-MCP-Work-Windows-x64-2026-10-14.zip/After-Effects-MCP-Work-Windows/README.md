# Standalone After Effects MCP

Read START-HERE.md first. For installation with work Codex, use WORK-CODEX-INSTALL-PROMPT.txt.
