// Standalone entry point. Protocol output only; diagnostics go to stderr.
import "./upstream/dist/index.js";
