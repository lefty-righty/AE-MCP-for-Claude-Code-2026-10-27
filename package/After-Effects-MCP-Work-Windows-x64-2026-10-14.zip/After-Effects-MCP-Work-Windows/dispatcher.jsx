// mcp-aftereffects dispatcher — invoked by `AfterFX.exe -r dispatcher.jsx`.
//
// Contract with the Node side:
//   1. Node writes <runtime>/request-<id>.json:
//      { id, label, code, payload, undoGroup }
//   2. Node spawns `AfterFX.exe -r dispatcher.jsx`
//   3. We locate the mailbox, pick the OLDEST pending request-*.json, DELETE it
//      (consume-on-read), eval `code` with `payload` in scope — inside an undo
//      group unless the request set `undoGroup: false` — and write
//      <runtime>/response-<id>.json atomically.
//   4. Node polls for response-<id>.json — only ever its own.
//
// Per-id files, not a single request.json/response.json pair: two MCP clients
// (or two server processes) share one AE instance and therefore one mailbox.
// With a single pair, one client could delete another's response or overwrite
// an unconsumed request. With per-id files neither is expressible — each
// dispatcher run consumes exactly one request and answers exactly its author.
//
// The id comes from the FILENAME, not the JSON body, so even a corrupt or
// unparseable request still produces a correlated response instead of a
// 60-second timeout on the Node side.
//
// Consume-on-read matters: when a call times out Node-side, its spawned
// dispatcher run may still be queued inside AE. Without consumption that stale
// run would pick up another pending request and execute it — while that
// request's own spawn executes it a second time (double mutation). With
// consumption, exactly one dispatcher run executes each request; a spawn that
// finds no pending request logs and exits WITHOUT writing anything.
//
// All other failure modes must write a response — never let an exception
// escape to AE's modal error dialog. If we crash before writing, Node will
// time out. Two mechanisms enforce that here: `describeError` (never
// concatenate a raw exception — see below) and the top-level guard at the
// bottom of this file.

// Minimal JSON polyfill for ExtendScript (ES3).
// Installed only when the global JSON is missing. Whether that is the case in
// any given After Effects build is not something to rely on either way: the
// fallback below is written to be safe on untrusted input regardless, because
// everything the dispatcher reads — including caller-supplied project
// documents travelling as `payload` — flows through JSON.parse.
if (typeof JSON === "undefined" || !JSON || typeof JSON.stringify !== "function" || typeof JSON.parse !== "function") {
    (function () {
        var escMap = {
            "\\": "\\\\",
            "\"": "\\\"",
            "\b": "\\b",
            "\f": "\\f",
            "\n": "\\n",
            "\r": "\\r",
            "\t": "\\t"
        };
        function escString(s) {
            var out = "\"";
            for (var i = 0; i < s.length; i++) {
                var ch = s.charAt(i);
                var code = s.charCodeAt(i);
                // `if (escMap[ch])` would be wrong here, and catastrophically so.
                // ExtendScript hangs its operator-overload hooks off
                // Object.prototype under one-character names, so on AE 26.3
                // escMap["-"], ["+"], ["*"] and ["/"] each resolve to an
                // inherited FUNCTION rather than undefined. The truthiness test
                // passes, `out +=` gets an object it cannot coerce, and the
                // whole stringify call dies with "Object of type Function found
                // where a Number, Array, or Property is needed". Every response
                // carries a hyphenated UUID id, so that was every response: no
                // file written, and the caller timing out after 60s.
                // Only a string is a real hit — check the type, not the truth.
                var esc = escMap[ch];
                if (typeof esc === "string") {
                    out += esc;
                } else if (code < 0x20 || code === 0x7f) {
                    var hex = code.toString(16);
                    while (hex.length < 4) hex = "0" + hex;
                    out += "\\u" + hex;
                } else {
                    out += ch;
                }
            }
            return out + "\"";
        }
        function stringify(v) {
            if (v === null || v === undefined) return "null";
            var t = typeof v;
            if (t === "number") {
                return isFinite(v) ? String(v) : "null";
            }
            if (t === "boolean") return v ? "true" : "false";
            if (t === "string") return escString(v);
            if (t === "object") {
                if (v instanceof Array || (typeof v.length === "number" && v.hasOwnProperty && v.hasOwnProperty("length"))) {
                    var parts = [];
                    for (var i = 0; i < v.length; i++) {
                        parts.push(stringify(v[i]));
                    }
                    return "[" + parts.join(",") + "]";
                }
                var kparts = [];
                for (var k in v) {
                    if (!v.hasOwnProperty(k)) continue;
                    var val = v[k];
                    if (typeof val === "function" || typeof val === "undefined") continue;
                    kparts.push(escString(k) + ":" + stringify(val));
                }
                return "{" + kparts.join(",") + "}";
            }
            return "null";
        }
        function parse(text) {
            // eval is the only parser available in ES3, so it is guarded by
            // Crockford's four-stage check from json2.js: after neutralizing
            // escape sequences and whole string literals, whatever remains must
            // consist solely of JSON structural characters. Anything that could
            // execute — a call, an identifier, an assignment — leaves a
            // character the final test rejects.
            //
            // The guard is NOT decoration. Untrusted content reaches here: the
            // dispatcher parses the whole request file with this, and a request
            // carries `payload`, which for ae_project_import_json is the
            // contents of an arbitrary .json file the caller pointed at.
            var t = String(text);
            // U+2028/U+2029 are legal raw inside JSON strings but are line
            // terminators to this ES3 parser — escape before validating.
            t = t.replace(/\u2028/g, "\\u2028").replace(/\u2029/g, "\\u2029");
            // Three stages, in this order: neutralize escape sequences, then
            // collapse every complete string/number/keyword to a single "]",
            // then drop the opening brackets that legitimately precede a value.
            var probe = t
                .replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g, "@")
                .replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, "]")
                .replace(/(?:^|:|,)(?:\s*\[)+/g, "");
            if (!/^[\],:{}\s]*$/.test(probe)) {
                throw new Error("JSON.parse: input is not valid JSON");
            }
            return eval("(" + t + ")");
        }
        JSON = { stringify: stringify, parse: parse };
    })();
}

// mcp-aftereffects shared JSX helpers — included by dispatcher.jsx so every tool call
// has these in scope. Keep this file ES3-compatible: var only, no arrow
// functions, no Array.prototype.map/filter, no template strings.

var AE = AE || {};

// ---------- Talking about exceptions ----------

/**
 * Render a caught exception as text. Use this instead of `"failed: " + e`,
 * always — the concatenation is not the harmless shorthand it looks like.
 * ExtendScript cannot coerce an Error to a primitive, so `+ e` throws on its
 * own ("Object of type Error found where a Number, Array, or Property is
 * needed") from inside the handler that was supposed to report the original
 * failure: the real error is swallowed and a bogus one takes its place. In a
 * generated operation that turns a recoverable warning into a failed call; in
 * the dispatcher it used to escape as far as AE's modal error dialog.
 *
 * dispatcher.jsx carries its own copy of this so it can still report failures
 * when an #include has not taken. Keep the two in step.
 */
AE.errText = function (e) {
    try {
        if (e === null || e === undefined) return "unknown error";
        if (typeof e === "string") return e;
        var msg = (e.message === undefined || e.message === null) ? "" : String(e.message);
        if (msg.length === 0) msg = "error";
        if (e.line !== undefined && e.line !== null) msg += " (line " + String(e.line) + ")";
        return msg;
    } catch (eFmt) {
        return "unformattable error";
    }
};

// ---------- Project item lookup ----------

AE.findItemById = function (id) {
    var proj = app.project;
    for (var i = 1; i <= proj.numItems; i++) {
        if (proj.item(i).id === id) return proj.item(i);
    }
    return null;
};

// Find any project item by numeric id or exact name (first match wins).
AE.findItem = function (idOrName) {
    if (typeof idOrName === "number") return AE.findItemById(idOrName);
    var proj = app.project;
    var name = String(idOrName);
    for (var i = 1; i <= proj.numItems; i++) {
        if (proj.item(i).name === name) return proj.item(i);
    }
    return null;
};

// Find a FolderItem by id or name. null/undefined resolves to the root folder.
AE.findFolder = function (idOrName) {
    if (idOrName === null || idOrName === undefined) return app.project.rootFolder;
    var it = AE.findItem(idOrName);
    return (it && it instanceof FolderItem) ? it : null;
};

AE.findCompByNameOrId = function (nameOrId) {
    var proj = app.project;
    if (typeof nameOrId === "number") {
        var byId = AE.findItemById(nameOrId);
        if (byId && byId instanceof CompItem) return byId;
        // fall through: treat number as 1-based index
        if (nameOrId >= 1 && nameOrId <= proj.numItems && proj.item(nameOrId) instanceof CompItem) {
            return proj.item(nameOrId);
        }
        return null;
    }
    for (var i = 1; i <= proj.numItems; i++) {
        var it = proj.item(i);
        if (it instanceof CompItem && it.name === nameOrId) return it;
    }
    return null;
};

// ---------- Comp/Layer pattern matching ----------

// Find comps by name, id, or glob pattern ('*' = all, 'review_id_*' = prefix match).
AE.findComps = function (nameOrIdOrPattern) {
    var proj = app.project;
    if (typeof nameOrIdOrPattern === "number") {
        var c = AE.findItemById(nameOrIdOrPattern);
        return (c && c instanceof CompItem) ? [c] : [];
    }
    var pat = String(nameOrIdOrPattern);
    var results = [];
    var isGlob = pat.indexOf("*") !== -1;
    for (var i = 1; i <= proj.numItems; i++) {
        var item = proj.item(i);
        if (!(item instanceof CompItem)) continue;
        if (isGlob) {
            // Simple glob: 'abc*' = startsWith, '*abc' = endsWith, '*' = all
            if (pat === "*") { results.push(item); continue; }
            var parts = pat.split("*");
            var match = true;
            var pos = 0;
            for (var p = 0; p < parts.length; p++) {
                if (parts[p].length === 0) continue;
                if (p === parts.length - 1) {
                    // Pattern does not end with '*': the final segment must
                    // end exactly at the end of the name.
                    var tailStart = item.name.length - parts[p].length;
                    if (tailStart < pos || item.name.substring(tailStart) !== parts[p]) { match = false; }
                    break;
                }
                var idx = item.name.indexOf(parts[p], pos);
                if (idx === -1) { match = false; break; }
                if (p === 0 && idx !== 0) { match = false; break; }
                pos = idx + parts[p].length;
            }
            if (match) results.push(item);
        } else {
            if (item.name === pat) results.push(item);
        }
    }
    return results;
};

// Find a layer by stable id (Layer.id, AE 22.0+). Uses app.project.layerByID
// (a Project method, not CompItem) when available, checking the hit belongs to
// this comp; falls back to a scan so pre-22 hosts degrade gracefully.
AE.findLayerById = function (comp, id) {
    try {
        if (typeof app.project.layerByID === "function") {
            var byId = app.project.layerByID(id);
            if (byId) {
                return (byId.containingComp && byId.containingComp.id === comp.id) ? byId : null;
            }
        }
    } catch (eById) { /* fall through to scan */ }
    for (var i = 1; i <= comp.numLayers; i++) {
        try { if (comp.layer(i).id === id) return comp.layer(i); } catch (eScan) {}
    }
    return null;
};

// Find a layer in a comp by index (number), name (string), or { id: n }
// (stable Layer.id reference that survives reordering and renaming).
AE.findLayerInComp = function (comp, indexOrName) {
    if (indexOrName !== null && typeof indexOrName === "object" && typeof indexOrName.id === "number") {
        return AE.findLayerById(comp, indexOrName.id);
    }
    if (typeof indexOrName === "number") {
        if (indexOrName >= 1 && indexOrName <= comp.numLayers) return comp.layer(indexOrName);
        return null;
    }
    var name = String(indexOrName);
    for (var i = 1; i <= comp.numLayers; i++) {
        if (comp.layer(i).name === name) return comp.layer(i);
    }
    return null;
};

// Resolve layer target: number=index, "selected"=selected layers array, string=name match,
// { id: n }=stable Layer.id. Always returns an array of layers.
AE.resolveLayers = function (comp, target) {
    if (target !== null && typeof target === "object" && typeof target.id === "number") {
        var byId = AE.findLayerById(comp, target.id);
        return byId ? [byId] : [];
    }
    if (typeof target === "number") {
        if (target >= 1 && target <= comp.numLayers) return [comp.layer(target)];
        return [];
    }
    var s = String(target);
    if (s === "selected") {
        var sel = [];
        for (var i = 1; i <= comp.numLayers; i++) {
            if (comp.layer(i).selected) sel.push(comp.layer(i));
        }
        return sel;
    }
    if (s === "all") {
        var all = [];
        for (var i2 = 1; i2 <= comp.numLayers; i2++) all.push(comp.layer(i2));
        return all;
    }
    // By name
    for (var i3 = 1; i3 <= comp.numLayers; i3++) {
        if (comp.layer(i3).name === s) return [comp.layer(i3)];
    }
    return [];
};

// ---------- Enum-valued layer attributes ----------
// JSON can't carry ExtendScript enum objects, so layer.set_props accepts
// well-known string names and translates them here. A value that is not a
// string, or a key/name this table doesn't know, passes through untouched —
// the plain assignment then succeeds on its own or reports its own error.
// Built lazily; each enum family guarded so one missing global (old AE)
// doesn't take the whole table down. Entries whose enum member resolved to
// undefined are dropped — assigning undefined would throw a misleading error.
AE._layerEnumMaps = null;
AE.coerceLayerPropValue = function (key, val) {
    if (typeof val !== "string") return val;
    if (AE._layerEnumMaps === null) {
        var maps = {};
        try {
            maps.autoOrient = {
                off: AutoOrientType.NO_AUTO_ORIENT,
                alongPath: AutoOrientType.ALONG_PATH,
                cameraOrPointOfInterest: AutoOrientType.CAMERA_OR_POINT_OF_INTEREST,
                charactersTowardCamera: AutoOrientType.CHARACTERS_TOWARD_CAMERA
            };
        } catch (eAo) {}
        try {
            maps.quality = {
                best: LayerQuality.BEST,
                draft: LayerQuality.DRAFT,
                wireframe: LayerQuality.WIREFRAME
            };
        } catch (eQ) {}
        try {
            maps.samplingQuality = {
                bilinear: LayerSamplingQuality.BILINEAR,
                bicubic: LayerSamplingQuality.BICUBIC
            };
        } catch (eSq) {}
        try {
            maps.frameBlendingType = {
                off: FrameBlendingType.NO_FRAME_BLEND,
                frameMix: FrameBlendingType.FRAME_MIX,
                pixelMotion: FrameBlendingType.PIXEL_MOTION
            };
        } catch (eFb) {}
        try {
            maps.blendingMode = {
                normal: BlendingMode.NORMAL, dissolve: BlendingMode.DISSOLVE,
                dancingDissolve: BlendingMode.DANCING_DISSOLVE,
                darken: BlendingMode.DARKEN, multiply: BlendingMode.MULTIPLY,
                colorBurn: BlendingMode.COLOR_BURN, classicColorBurn: BlendingMode.CLASSIC_COLOR_BURN,
                linearBurn: BlendingMode.LINEAR_BURN, darkerColor: BlendingMode.DARKER_COLOR,
                add: BlendingMode.ADD, lighten: BlendingMode.LIGHTEN,
                screen: BlendingMode.SCREEN, colorDodge: BlendingMode.COLOR_DODGE,
                classicColorDodge: BlendingMode.CLASSIC_COLOR_DODGE,
                linearDodge: BlendingMode.LINEAR_DODGE, lighterColor: BlendingMode.LIGHTER_COLOR,
                overlay: BlendingMode.OVERLAY, softLight: BlendingMode.SOFT_LIGHT,
                hardLight: BlendingMode.HARD_LIGHT, linearLight: BlendingMode.LINEAR_LIGHT,
                vividLight: BlendingMode.VIVID_LIGHT, pinLight: BlendingMode.PIN_LIGHT,
                hardMix: BlendingMode.HARD_MIX, difference: BlendingMode.DIFFERENCE,
                classicDifference: BlendingMode.CLASSIC_DIFFERENCE, exclusion: BlendingMode.EXCLUSION,
                subtract: BlendingMode.SUBTRACT, divide: BlendingMode.DIVIDE,
                hue: BlendingMode.HUE, saturation: BlendingMode.SATURATION,
                color: BlendingMode.COLOR, luminosity: BlendingMode.LUMINOSITY,
                stencilAlpha: BlendingMode.STENCIL_ALPHA, stencilLuma: BlendingMode.STENCIL_LUMA,
                alphaAdd: BlendingMode.ALPHA_ADD, luminescentPremul: BlendingMode.LUMINESCENT_PREMUL
            };
            // The API spells it SILHOUETE_* (one T) — an Adobe typo old enough
            // to be contractual. Probe both spellings, keep whichever exists.
            var silA = BlendingMode.SILHOUETE_ALPHA;
            if (silA === undefined) silA = BlendingMode.SILHOUETTE_ALPHA;
            var silL = BlendingMode.SILHOUETE_LUMA;
            if (silL === undefined) silL = BlendingMode.SILHOUETTE_LUMA;
            maps.blendingMode.silhouetteAlpha = silA;
            maps.blendingMode.silhouetteLuma = silL;
        } catch (eBm) {}
        try {
            maps.lightType = {
                spot: LightType.SPOT,
                parallel: LightType.PARALLEL,
                point: LightType.POINT,
                ambient: LightType.AMBIENT
            };
        } catch (eLt) {}
        // ENVIRONMENT is 24.3+ — probed separately so a build without it keeps
        // the four classic light types even if the member access throws.
        try {
            if (maps.lightType && LightType.ENVIRONMENT !== undefined) {
                maps.lightType.environment = LightType.ENVIRONMENT;
            }
        } catch (eEnv) {}
        // Drop entries whose enum member is missing on this AE build.
        for (var mk in maps) {
            if (!maps.hasOwnProperty(mk)) continue;
            for (var vk in maps[mk]) {
                if (maps[mk].hasOwnProperty(vk) && maps[mk][vk] === undefined) delete maps[mk][vk];
            }
        }
        AE._layerEnumMaps = maps;
    }
    var map = AE._layerEnumMaps.hasOwnProperty(key) ? AE._layerEnumMaps[key] : null;
    if (map !== null && map.hasOwnProperty(val)) return map[val];
    return val;
};

// ---------- Basic serialization ----------

AE.serializeItemSummary = function (item) {
    var type = "UnknownItem";
    if (item instanceof FolderItem) type = "FolderItem";
    else if (item instanceof CompItem) type = "CompItem";
    else if (item instanceof FootageItem) type = "FootageItem";
    var out = {
        id: item.id,
        name: item.name,
        type: type,
        parentFolderId: item.parentFolder ? item.parentFolder.id : null,
        parentFolderName: item.parentFolder ? item.parentFolder.name : null,
        label: item.label,
        comment: item.comment
    };
    if (item instanceof CompItem) {
        out.width = item.width;
        out.height = item.height;
        out.frameRate = item.frameRate;
        out.duration = item.duration;
        out.layerCount = item.numLayers;
        out.bgColor = [item.bgColor[0], item.bgColor[1], item.bgColor[2]];
    }
    if (item instanceof FootageItem) {
        out.width = item.width;
        out.height = item.height;
        out.duration = item.duration;
        var src = item.mainSource;
        if (src instanceof SolidSource) {
            out.sourceKind = "solid";
            out.color = [src.color[0], src.color[1], src.color[2]];
        } else if (src instanceof FileSource) {
            out.sourceKind = "file";
            out.file = src.file ? src.file.fsName.replace(/\\/g, "/") : null;
            out.missingFootagePath = (src.missingFootagePath && src.missingFootagePath.length > 0) ? src.missingFootagePath : null;
        } else if (src instanceof PlaceholderSource) {
            out.sourceKind = "placeholder";
        } else {
            out.sourceKind = "unknown";
        }
    }
    return out;
};

AE.serializeLayerSummary = function (layer) {
    var type = "Layer";
    if (layer instanceof AVLayer) type = "AVLayer";
    if (layer instanceof ShapeLayer) type = "ShapeLayer";
    if (layer instanceof TextLayer) type = "TextLayer";
    if (layer instanceof CameraLayer) type = "CameraLayer";
    if (layer instanceof LightLayer) type = "LightLayer";
    // AE 24.4+ / 26.3+ layer classes. ThreeDModelLayer subclasses AVLayer;
    // ParametricMeshLayer does NOT (verified on 26.3), so both need their own
    // probe-guarded checks rather than relying on the chain above.
    try { if (typeof ThreeDModelLayer !== "undefined" && layer instanceof ThreeDModelLayer) type = "ThreeDModelLayer"; } catch (e3d) {}
    try { if (typeof ParametricMeshLayer !== "undefined" && layer instanceof ParametricMeshLayer) type = "ParametricMeshLayer"; } catch (ePm) {}
    var out = {
        index: layer.index,
        // Stable layer id (AE 22.0+) — survives reordering/renaming. null on older hosts.
        id: AE.safeGet(function () { return layer.id; }, null),
        name: layer.name,
        type: type,
        enabled: layer.enabled,
        solo: layer.solo,
        shy: layer.shy,
        locked: layer.locked,
        inPoint: layer.inPoint,
        outPoint: layer.outPoint,
        startTime: layer.startTime,
        stretch: layer.stretch,
        parentIndex: layer.parent ? layer.parent.index : null,
        label: layer.label
    };
    if (layer instanceof AVLayer) {
        out.width = layer.width;
        out.height = layer.height;
        out.hasVideo = layer.hasVideo;
        out.hasAudio = layer.hasAudio;
        out.threeDLayer = layer.threeDLayer;
        out.sourceId = (layer.source && layer.source.id) ? layer.source.id : null;
        out.sourceName = layer.source ? layer.source.name : null;
    }
    if (layer instanceof TextLayer) {
        try {
            var doc = layer.property("Source Text").value;
            out.text = doc.text;
            out.fontSize = doc.fontSize;
            out.font = doc.font;
            out.fillColor = [doc.fillColor[0], doc.fillColor[1], doc.fillColor[2]];
        } catch (eT) {
            out.text = null;
        }
    }
    return out;
};

// ---------- Transform snapshot (values at time 0) ----------

AE.serializeTransform = function (layer) {
    var xf = layer.transform;
    function v(name) {
        try {
            var p = xf.property(name);
            if (!p) return null;
            var val = p.value;
            if (val && val.length !== undefined) {
                var arr = [];
                for (var i = 0; i < val.length; i++) arr.push(val[i]);
                return arr;
            }
            return val;
        } catch (e) { return null; }
    }
    return {
        anchorPoint: v("Anchor Point"),
        position: v("Position"),
        scale: v("Scale"),
        rotation: v("Rotation"),
        opacity: v("Opacity")
    };
};

// ---------- Property tree walker (for export) ----------
// Walks a PropertyGroup (or indexed group) and serializes every leaf Property
// with its current value and keyframes. Skips properties that can't be
// serialized (BridgeTalk, byte arrays, etc.) by falling back to null.

AE.PROPERTY_VALUE_TYPE_NAMES = {};
(function buildPvtNames() {
    try {
        AE.PROPERTY_VALUE_TYPE_NAMES[PropertyValueType.NO_VALUE] = "NO_VALUE";
        AE.PROPERTY_VALUE_TYPE_NAMES[PropertyValueType.ThreeD_SPATIAL] = "ThreeD_SPATIAL";
        AE.PROPERTY_VALUE_TYPE_NAMES[PropertyValueType.ThreeD] = "ThreeD";
        AE.PROPERTY_VALUE_TYPE_NAMES[PropertyValueType.TwoD_SPATIAL] = "TwoD_SPATIAL";
        AE.PROPERTY_VALUE_TYPE_NAMES[PropertyValueType.TwoD] = "TwoD";
        AE.PROPERTY_VALUE_TYPE_NAMES[PropertyValueType.OneD] = "OneD";
        AE.PROPERTY_VALUE_TYPE_NAMES[PropertyValueType.COLOR] = "COLOR";
        AE.PROPERTY_VALUE_TYPE_NAMES[PropertyValueType.CUSTOM_VALUE] = "CUSTOM_VALUE";
        AE.PROPERTY_VALUE_TYPE_NAMES[PropertyValueType.MARKER] = "MARKER";
        AE.PROPERTY_VALUE_TYPE_NAMES[PropertyValueType.LAYER_INDEX] = "LAYER_INDEX";
        AE.PROPERTY_VALUE_TYPE_NAMES[PropertyValueType.MASK_INDEX] = "MASK_INDEX";
        AE.PROPERTY_VALUE_TYPE_NAMES[PropertyValueType.SHAPE] = "SHAPE";
        AE.PROPERTY_VALUE_TYPE_NAMES[PropertyValueType.TEXT_DOCUMENT] = "TEXT_DOCUMENT";
    } catch (e) { /* older AE: some enum members might be absent */ }
})();

// Safely call a getter that may throw or return undefined. Returns the fallback on any failure.
AE.safeGet = function (fn, fallback) {
    try { var v = fn(); return (v === undefined) ? fallback : v; } catch (e) { return fallback; }
};

AE.valueToJson = function (val, _depth) {
    if (val === null || val === undefined) return null;
    var t = typeof val;
    if (t === "number" || t === "boolean" || t === "string") return val;
    if (val instanceof Array) {
        var arr = [];
        for (var i = 0; i < val.length; i++) arr.push(AE.valueToJson(val[i], (_depth || 0) + 1));
        return arr;
    }
    // TextDocument special-case — check before generic array-like because
    // TextDocument does not expose a length property.
    if (val.text !== undefined && typeof val.text === "string" && val.fontSize !== undefined) {
        return {
            __kind: "TextDocument",
            text: val.text,
            font: AE.safeGet(function () { return val.font; }, null),
            fontFamily: AE.safeGet(function () { return val.fontFamily; }, null),
            fontStyle: AE.safeGet(function () { return val.fontStyle; }, null),
            fontSize: val.fontSize,
            fillColor: AE.safeGet(function () { return val.fillColor ? [val.fillColor[0], val.fillColor[1], val.fillColor[2]] : null; }, null),
            strokeColor: AE.safeGet(function () { return val.strokeColor ? [val.strokeColor[0], val.strokeColor[1], val.strokeColor[2]] : null; }, null),
            strokeWidth: AE.safeGet(function () { return val.strokeWidth; }, 0),
            justification: AE.safeGet(function () { return String(val.justification); }, null),
            tracking: AE.safeGet(function () { return val.tracking; }, 0),
            leading: AE.safeGet(function () { return val.leading; }, 0),
            baselineShift: AE.safeGet(function () { return val.baselineShift; }, 0),
            applyFill: AE.safeGet(function () { return val.applyFill; }, true),
            applyStroke: AE.safeGet(function () { return val.applyStroke; }, false),
            boxText: AE.safeGet(function () { return val.boxText; }, false),
            boxTextSize: AE.safeGet(function () { return val.boxText && val.boxTextSize ? [val.boxTextSize[0], val.boxTextSize[1]] : null; }, null),
            boxTextPos: AE.safeGet(function () { return val.boxText && val.boxTextPos ? [val.boxTextPos[0], val.boxTextPos[1]] : null; }, null)
        };
    }
    // Shape object (masks / shape layer paths)
    if (val.vertices !== undefined) {
        return {
            __kind: "Shape",
            closed: val.closed,
            vertices: AE.valueToJson(val.vertices),
            inTangents: AE.valueToJson(val.inTangents),
            outTangents: AE.valueToJson(val.outTangents)
        };
    }
    // MarkerValue — from marker keyframes (comp.markerProperty or layer.marker)
    if (val.comment !== undefined && val.chapter !== undefined) {
        return {
            __kind: "MarkerValue",
            comment: AE.safeGet(function () { return val.comment; }, ""),
            chapter: AE.safeGet(function () { return val.chapter; }, ""),
            url: AE.safeGet(function () { return val.url; }, ""),
            frameTarget: AE.safeGet(function () { return val.frameTarget; }, ""),
            cuePointName: AE.safeGet(function () { return val.cuePointName; }, ""),
            duration: AE.safeGet(function () { return val.duration; }, 0),
            label: AE.safeGet(function () { return val.label; }, 0),
            protectedRegion: AE.safeGet(function () { return val.protectedRegion; }, false)
        };
    }
    // Array-like (color tuples, position tuples). Check AFTER the typed
    // objects above so we don't accidentally treat them as arrays.
    if (val.length !== undefined && typeof val.length === "number") {
        var out = [];
        for (var j = 0; j < val.length; j++) out.push(AE.valueToJson(val[j], (_depth || 0) + 1));
        return out;
    }
    // Generic object (swatch data, usedFonts usage records, design-axis
    // entries). Depth-capped and function-skipping: AE host objects reachable
    // from here can fan out into the whole project graph, and their methods
    // enumerate in for..in.
    var d = typeof _depth === "number" ? _depth : 0;
    if (d < 4) {
        var objOut = {};
        var got = false;
        var kept = 0;
        for (var k in val) {
            if (kept >= 64) break;
            var v2;
            try { v2 = val[k]; } catch (eK) { continue; }
            if (typeof v2 === "function") continue;
            var enc = AE.valueToJson(v2, d + 1);
            if (enc === null && v2 !== null && v2 !== undefined) continue;
            objOut[k] = enc;
            got = true;
            kept++;
        }
        if (got) return objOut;
    }
    return null;
};

AE.serializeProperty = function (prop) {
    var out = {
        name: prop.name,
        matchName: prop.matchName,
        propertyValueType: AE.PROPERTY_VALUE_TYPE_NAMES[prop.propertyValueType] || prop.propertyValueType
    };
    // Avoid touching NO_VALUE groups and properties marked as not-yet-created
    if (prop.propertyValueType === PropertyValueType.NO_VALUE) {
        return out;
    }
    try {
        out.value = AE.valueToJson(prop.value);
    } catch (e) {
        out.value = null;
    }
    if (prop.canSetExpression && prop.expressionEnabled && prop.expression && prop.expression.length > 0) {
        out.expression = prop.expression;
    }
    if (prop.numKeys && prop.numKeys > 0) {
        var keys = [];
        for (var k = 1; k <= prop.numKeys; k++) {
            var keyVal;
            try { keyVal = AE.valueToJson(prop.keyValue(k)); } catch (eKv) { keyVal = null; }
            var inInterp = null, outInterp = null;
            try { inInterp = prop.keyInInterpolationType(k); } catch (eI) {}
            try { outInterp = prop.keyOutInterpolationType(k); } catch (eO) {}
            keys.push({
                time: prop.keyTime(k),
                value: keyVal,
                inInterp: inInterp,
                outInterp: outInterp
            });
        }
        out.keyframes = keys;
    }
    return out;
};

AE.serializePropertyGroup = function (group, depth, maxDepth) {
    if (depth === undefined) depth = 0;
    if (maxDepth === undefined) maxDepth = 6;
    var out = {
        name: group.name,
        matchName: group.matchName,
        properties: [],
        groups: []
    };
    if (depth >= maxDepth) return out;
    for (var i = 1; i <= group.numProperties; i++) {
        var child;
        try { child = group.property(i); } catch (e) { continue; }
        if (!child) continue;
        if (child.propertyType === PropertyType.PROPERTY) {
            out.properties.push(AE.serializeProperty(child));
        } else if (child.propertyType === PropertyType.NAMED_GROUP || child.propertyType === PropertyType.INDEXED_GROUP) {
            out.groups.push(AE.serializePropertyGroup(child, depth + 1, maxDepth));
        }
    }
    return out;
};

// ---------- Layer full serialization ----------

AE.serializeLayerFull = function (layer, opts) {
    opts = opts || {};
    var out = AE.serializeLayerSummary(layer);
    // Parent by index for simple remapping on import.
    out.parent = layer.parent ? { index: layer.parent.index, name: layer.parent.name } : null;
    // Property tree (Transform + Effects + Masks + Text + Contents + Material Options + Audio)
    if (opts.includeProperties !== false) {
        try { out.transformGroup = AE.serializePropertyGroup(layer.property("Transform"), 0, 4); } catch (eT) { out.transformGroup = null; }
        try {
            var effects = layer.property("Effects");
            out.effectsGroup = (effects && effects.numProperties > 0) ? AE.serializePropertyGroup(effects, 0, 6) : null;
        } catch (eE) { out.effectsGroup = null; }
        try {
            var masks = layer.property("Masks");
            out.masksGroup = (masks && masks.numProperties > 0) ? AE.serializePropertyGroup(masks, 0, 5) : null;
        } catch (eM) { out.masksGroup = null; }
        if (layer instanceof TextLayer) {
            try { out.textGroup = AE.serializePropertyGroup(layer.property("Text"), 0, 4); } catch (eTx) { out.textGroup = null; }
        }
        if (layer instanceof ShapeLayer) {
            // Shape layers have a Contents group that holds the shape vector
            // graphics. Walk deeper because shape groups nest several levels.
            try { out.contentsGroup = AE.serializePropertyGroup(layer.property("Contents"), 0, 10); } catch (eCt) { out.contentsGroup = null; }
        }
        // Material options (3D layers)
        if (layer instanceof AVLayer && layer.threeDLayer) {
            try {
                var mat = layer.property("Material Options");
                out.materialOptionsGroup = mat ? AE.serializePropertyGroup(mat, 0, 3) : null;
            } catch (eMo) { out.materialOptionsGroup = null; }
        }
        // Audio (if layer has audio)
        if (layer instanceof AVLayer && layer.hasAudio) {
            try {
                var au = layer.property("Audio");
                out.audioGroup = au ? AE.serializePropertyGroup(au, 0, 3) : null;
            } catch (eAu) { out.audioGroup = null; }
        }
        // Time Remap (AVLayer only, must be enabled)
        if (layer instanceof AVLayer) {
            try {
                out.timeRemapEnabled = !!layer.timeRemapEnabled;
                if (layer.timeRemapEnabled) {
                    var tr = layer.property("Time Remap");
                    out.timeRemapProperty = tr ? AE.serializeProperty(tr) : null;
                }
            } catch (eTr) { /* ignore */ }
        }
        // Layer markers — layer.marker is a NamedGroup with keyframed MarkerValues
        try {
            var marker = layer.property("Marker");
            if (marker && marker.numKeys > 0) {
                out.markers = AE.serializeProperty(marker);
            }
        } catch (eMk) { /* ignore */ }
    }
    return out;
};

// ---------- Keyframe snapshot / rebuild ----------
// Captures every scriptable attribute of a property's keyframes so they can be
// re-created after retiming (shift/scale) or on another property (copy).
// Interpolation, temporal ease, and spatial tangents are restored best-effort.

AE.snapshotKeys = function (prop) {
    var keys = [];
    for (var k = 1; k <= prop.numKeys; k++) {
        var key = { time: prop.keyTime(k), value: prop.keyValue(k) };
        try { key.inInterp = prop.keyInInterpolationType(k); } catch (e1) {}
        try { key.outInterp = prop.keyOutInterpolationType(k); } catch (e2) {}
        try { key.inEase = prop.keyInTemporalEase(k); } catch (e3) {}
        try { key.outEase = prop.keyOutTemporalEase(k); } catch (e4) {}
        try { key.temporalContinuous = prop.keyTemporalContinuous(k); } catch (e5) {}
        try { key.temporalAutoBezier = prop.keyTemporalAutoBezier(k); } catch (e6) {}
        try {
            if (prop.isSpatial) {
                key.inSpatialTangent = prop.keyInSpatialTangent(k);
                key.outSpatialTangent = prop.keyOutSpatialTangent(k);
                key.spatialContinuous = prop.keySpatialContinuous(k);
                key.spatialAutoBezier = prop.keySpatialAutoBezier(k);
                key.roving = prop.keyRoving(k);
            }
        } catch (e7) {}
        keys.push(key);
    }
    return keys;
};

AE.removeAllKeys = function (prop) {
    var removed = 0;
    while (prop.numKeys > 0) { prop.removeKey(prop.numKeys); removed++; }
    return removed;
};

// Re-create keys from a snapshot whose times the caller may have remapped.
// Two passes: values first, then interpolation attributes — writing bezier
// data while neighbours are still being inserted shifts the handles.
AE.applyKeys = function (prop, keys) {
    var i, key, ki;
    // addKey on a time that already carries a key returns the existing index
    // rather than adding one, so keys.length overstates the result whenever
    // two snapshot times collide or land on an existing key. Report what the
    // property actually gained.
    var before = prop.numKeys;
    for (i = 0; i < keys.length; i++) {
        key = keys[i];
        ki = prop.addKey(key.time);
        try { prop.setValueAtKey(ki, key.value); } catch (eV) {}
    }
    for (i = 0; i < keys.length; i++) {
        key = keys[i];
        ki = prop.nearestKeyIndex(key.time);
        // Ease before interpolation type: setting ease flips the key to
        // BEZIER, so a HOLD/LINEAR snapshot must be re-asserted afterwards.
        try { if (key.inEase && key.outEase) prop.setTemporalEaseAtKey(ki, key.inEase, key.outEase); } catch (eE) {}
        try { if (key.inInterp !== undefined && key.outInterp !== undefined) prop.setInterpolationTypeAtKey(ki, key.inInterp, key.outInterp); } catch (eI) {}
        try { if (key.temporalContinuous !== undefined) prop.setTemporalContinuousAtKey(ki, key.temporalContinuous); } catch (eC) {}
        try { if (key.temporalAutoBezier !== undefined) prop.setTemporalAutoBezierAtKey(ki, key.temporalAutoBezier); } catch (eB) {}
        try {
            if (key.inSpatialTangent !== undefined) {
                prop.setSpatialTangentsAtKey(ki, key.inSpatialTangent, key.outSpatialTangent);
                prop.setSpatialContinuousAtKey(ki, key.spatialContinuous);
                prop.setSpatialAutoBezierAtKey(ki, key.spatialAutoBezier);
                prop.setRovingAtKey(ki, key.roving);
            }
        } catch (eS) {}
    }
    return keys.length;
};

// ---------- Composition marker serialization ----------

AE.serializeCompMarkers = function (comp) {
    try {
        var mp = comp.markerProperty;
        if (!mp || mp.numKeys === 0) return null;
        return AE.serializeProperty(mp);
    } catch (e) { return null; }
};

// mcp-aftereffects project export — walks the entire project and produces a JSON
// document describing folders, comps (with full layer/property trees), solid
// footage, and file footage references. ES3-compatible.

AE.EXPORT_SCHEMA_VERSION = 2;
// v1: basic items + layers + transform/effects/masks/text
// v2: shape layer contents, layer/comp markers, time remap, material options, audio, extended text document fields

AE.exportProject = function () {
    var proj = app.project;
    var doc = {
        schemaVersion: AE.EXPORT_SCHEMA_VERSION,
        exportedAt: new Date().toString(),
        aeVersion: app.version,
        project: {
            file: proj.file ? proj.file.fsName.replace(/\\/g, "/") : null,
            bitsPerChannel: proj.bitsPerChannel,
            timeDisplayType: String(proj.timeDisplayType)
        },
        items: []
    };

    for (var i = 1; i <= proj.numItems; i++) {
        var it = proj.item(i);
        var entry = AE.serializeItemSummary(it);
        if (it instanceof CompItem) {
            entry.workAreaStart = it.workAreaStart;
            entry.workAreaDuration = it.workAreaDuration;
            entry.pixelAspect = it.pixelAspect;
            entry.shutterAngle = it.shutterAngle;
            entry.shutterPhase = it.shutterPhase;
            entry.motionBlur = it.motionBlur;
            entry.displayStartTime = it.displayStartTime;
            entry.layers = [];
            for (var li = 1; li <= it.numLayers; li++) {
                var lay = it.layer(li);
                entry.layers.push(AE.serializeLayerFull(lay, { includeProperties: true }));
            }
            entry.markers = AE.serializeCompMarkers(it);
        }
        if (it instanceof FootageItem) {
            // width/height/duration already in summary; nothing extra needed for solids.
            var src = it.mainSource;
            if (src instanceof SolidSource) {
                entry.sourceWidth = it.width;
                entry.sourceHeight = it.height;
                entry.alphaMode = src.alphaMode;
                try { entry.hasAlpha = src.hasAlpha; } catch (e) {}
            }
        }
        doc.items.push(entry);
    }
    return doc;
};

// mcp-aftereffects project import — reconstructs items and layers from a JSON
// document produced by AE.exportProject(). Returns a summary including an
// ID remap table (old id -> new id) and a list of warnings for things that
// could not be restored cleanly.
//
// Design:
//   1. Create all FolderItems first (flat pass), then wire up parentFolder.
//   2. Create FootageItems: solids from AE, file references via importFile
//      (fails gracefully if the file is missing).
//   3. Create CompItems.
//   4. For each comp, add its layers in order, remapping source item ids via
//      the remap table, then apply the property trees (transform/effects/
//      masks/text) and keyframes.
//   5. Wire up layer parenting last (since parents must exist).
//
// ES3-compatible. No arrow functions. No map/filter.

AE.importProject = function (doc, opts) {
    opts = opts || {};
    var warnings = [];
    var logs = [];
    function warn(msg) { warnings.push(msg); }
    function note(msg) { logs.push(msg); }

    if (!doc || !doc.items) {
        return { ok: false, error: "invalid document: missing items" };
    }
    if (doc.schemaVersion && doc.schemaVersion > AE.EXPORT_SCHEMA_VERSION) {
        warn("document schemaVersion " + doc.schemaVersion + " newer than runtime " + AE.EXPORT_SCHEMA_VERSION);
    }

    var proj = app.project;

    // Optionally clear the project first.
    if (opts.clearFirst) {
        var toRemove = [];
        for (var ci = 1; ci <= proj.numItems; ci++) toRemove.push(proj.item(ci));
        for (var ri = 0; ri < toRemove.length; ri++) {
            try { toRemove[ri].remove(); } catch (e) { /* some items can't be removed */ }
        }
    }

    // --- Pass 1: folders (flat create, wire parents in pass 5) ---
    var remap = {}; // old item id (string) -> new item
    var items = doc.items;

    var i;
    for (i = 0; i < items.length; i++) {
        var it = items[i];
        if (it.type === "FolderItem") {
            var f = proj.items.addFolder(it.name);
            remap[String(it.id)] = f;
        }
    }

    // --- Pass 2: footage items ---
    // AE has no direct API to create a standalone Solid FootageItem. The
    // idiom is to spin up a throwaway comp, call LayerCollection#addSolid
    // (which creates both the Solid footage and a layer using it), then
    // delete the throwaway comp. The FootageItem persists in the project's
    // Solids folder.
    for (i = 0; i < items.length; i++) {
        var fi = items[i];
        if (fi.type !== "FootageItem") continue;
        if (fi.sourceKind === "solid") {
            try {
                var color = fi.color || [1, 1, 1];
                var w = fi.sourceWidth || fi.width || 100;
                var h = fi.sourceHeight || fi.height || 100;
                var dur = fi.duration || 1;
                var pa = fi.pixelAspect || 1;
                var holder = proj.items.addComp("__mcp_ae_solid_holder__", w, h, pa, Math.max(1, dur), 30);
                var holderLayer = holder.layers.addSolid(color, fi.name, w, h, pa, dur);
                var solidSource = holderLayer.source; // FootageItem
                holder.remove();
                if (solidSource) {
                    remap[String(fi.id)] = solidSource;
                } else {
                    warn("addSolid produced no source for '" + fi.name + "'");
                }
            } catch (eSol) {
                warn("failed to create solid '" + fi.name + "': " + AE.errText(eSol));
            }
        } else if (fi.sourceKind === "file") {
            try {
                if (!fi.file) { warn("file footage '" + fi.name + "' has no path; skipped"); continue; }
                var jsFile = new File(fi.file);
                if (!jsFile.exists) {
                    warn("file footage '" + fi.file + "' not found on disk; creating placeholder");
                    // ItemCollection has no addFootage; use importPlaceholder so
                    // dependent layers still get a source item.
                    var phName = fi.name || String(fi.file);
                    var phW = fi.sourceWidth || fi.width || 1920;
                    var phH = fi.sourceHeight || fi.height || 1080;
                    var phFps = fi.frameRate || 30;
                    var phDur = fi.duration || 10;
                    var ph = proj.importPlaceholder(phName, phW, phH, phFps, phDur);
                    if (fi.name && ph.name !== fi.name) ph.name = fi.name;
                    remap[String(fi.id)] = ph;
                } else {
                    var imp = new ImportOptions(jsFile);
                    var importedItem = proj.importFile(imp);
                    // importedItem may be a FootageItem or a FolderItem for sequence
                    if (fi.name && importedItem.name !== fi.name) importedItem.name = fi.name;
                    remap[String(fi.id)] = importedItem;
                }
            } catch (eF) {
                warn("failed to import file '" + fi.file + "': " + AE.errText(eF));
            }
        } else {
            warn("unsupported sourceKind '" + fi.sourceKind + "' for item '" + fi.name + "'; skipped");
        }
    }

    // --- Pass 3: comps ---
    var compBindings = []; // { compItem, spec } — for pass 4 layer population
    for (i = 0; i < items.length; i++) {
        var ci = items[i];
        if (ci.type !== "CompItem") continue;
        var comp = proj.items.addComp(
            ci.name,
            Math.max(4, ci.width | 0),
            Math.max(4, ci.height | 0),
            ci.pixelAspect || 1,
            Math.max(1 / 60, ci.duration),
            ci.frameRate || 30
        );
        // Apply comp-level props
        try { if (ci.bgColor) comp.bgColor = ci.bgColor; } catch (e1) {}
        try { if (ci.workAreaStart !== undefined) comp.workAreaStart = ci.workAreaStart; } catch (e2) {}
        try { if (ci.workAreaDuration !== undefined) comp.workAreaDuration = ci.workAreaDuration; } catch (e3) {}
        try { if (ci.shutterAngle !== undefined) comp.shutterAngle = ci.shutterAngle; } catch (e4) {}
        try { if (ci.shutterPhase !== undefined) comp.shutterPhase = ci.shutterPhase; } catch (e5) {}
        try { if (ci.motionBlur !== undefined) comp.motionBlur = ci.motionBlur; } catch (e6) {}
        try { if (ci.displayStartTime !== undefined) comp.displayStartTime = ci.displayStartTime; } catch (e7) {}
        try { if (ci.comment) comp.comment = ci.comment; } catch (e8) {}
        // Comp markers
        try {
            if (ci.markers) AE.applyPropertyValue(comp.markerProperty, ci.markers);
        } catch (eCm) { warn("comp markers restore failed for '" + ci.name + "': " + AE.errText(eCm)); }
        remap[String(ci.id)] = comp;
        compBindings.push({ comp: comp, spec: ci });
    }

    // --- Pass 4: layers inside comps ---
    for (var cb = 0; cb < compBindings.length; cb++) {
        var binding = compBindings[cb];
        var compDst = binding.comp;
        var spec = binding.spec;
        if (!spec.layers) continue;
        // Layers were exported in top-to-bottom order (index 1 = top).
        // AE's Layers#add inserts new layers at the top, pushing existing ones
        // down. Adding in *reverse* order produces the original stacking.
        for (var lj = spec.layers.length - 1; lj >= 0; lj--) {
            var lspec = spec.layers[lj];
            var newLayer = null;
            try {
                if (lspec.type === "TextLayer") {
                    newLayer = compDst.layers.addText(lspec.text || "");
                } else if (lspec.type === "ShapeLayer") {
                    newLayer = compDst.layers.addShape();
                } else if (lspec.type === "CameraLayer") {
                    newLayer = compDst.layers.addCamera(lspec.name || "Camera", [compDst.width / 2, compDst.height / 2]);
                } else if (lspec.type === "LightLayer") {
                    newLayer = compDst.layers.addLight(lspec.name || "Light", [compDst.width / 2, compDst.height / 2]);
                } else {
                    // AVLayer: must have a source
                    if (lspec.sourceId != null) {
                        var src = remap[String(lspec.sourceId)];
                        if (!src) {
                            warn("layer '" + lspec.name + "' in comp '" + spec.name + "' references missing source id " + lspec.sourceId);
                            continue;
                        }
                        newLayer = compDst.layers.add(src);
                    } else {
                        warn("AVLayer '" + lspec.name + "' has no sourceId; skipped");
                        continue;
                    }
                }
                if (!newLayer) continue;
                if (lspec.name) newLayer.name = lspec.name;
                if (lspec.enabled !== undefined) newLayer.enabled = lspec.enabled;
                if (lspec.shy !== undefined) newLayer.shy = lspec.shy;
                if (lspec.solo !== undefined) newLayer.solo = lspec.solo;
                if (lspec.locked !== undefined) newLayer.locked = lspec.locked;
                if (lspec.label !== undefined) newLayer.label = lspec.label;
                if (lspec.startTime !== undefined) newLayer.startTime = lspec.startTime;
                if (lspec.inPoint !== undefined) newLayer.inPoint = lspec.inPoint;
                if (lspec.outPoint !== undefined) newLayer.outPoint = lspec.outPoint;
                if (lspec.stretch !== undefined && lspec.stretch !== 100) {
                    try { newLayer.stretch = lspec.stretch; } catch (eSt) {}
                }
                if (lspec.threeDLayer !== undefined && newLayer instanceof AVLayer) {
                    try { newLayer.threeDLayer = lspec.threeDLayer; } catch (e3d) {}
                }
                // Apply transform properties
                if (lspec.transformGroup) {
                    AE.applyPropertyGroup(newLayer.property("Transform"), lspec.transformGroup, warn);
                }
                // Apply effects (create each effect by matchName, then fill values)
                if (lspec.effectsGroup && lspec.effectsGroup.groups) {
                    var fxRoot = newLayer.property("Effects");
                    for (var ei = 0; ei < lspec.effectsGroup.groups.length; ei++) {
                        var effSpec = lspec.effectsGroup.groups[ei];
                        try {
                            var addedEffect = fxRoot.addProperty(effSpec.matchName);
                            if (effSpec.name) addedEffect.name = effSpec.name;
                            AE.applyPropertyGroup(addedEffect, effSpec, warn);
                        } catch (eEff) {
                            warn("could not add effect " + effSpec.matchName + " on layer '" + lspec.name + "': " + AE.errText(eEff));
                        }
                    }
                }
                // Apply masks
                if (lspec.masksGroup && lspec.masksGroup.groups) {
                    var maskRoot = newLayer.property("Masks");
                    for (var mi = 0; mi < lspec.masksGroup.groups.length; mi++) {
                        var mSpec = lspec.masksGroup.groups[mi];
                        try {
                            var addedMask = maskRoot.addProperty("ADBE Mask Atom");
                            if (mSpec.name) addedMask.name = mSpec.name;
                            AE.applyPropertyGroup(addedMask, mSpec, warn);
                        } catch (eMsk) {
                            warn("could not add mask '" + mSpec.name + "' on layer '" + lspec.name + "': " + AE.errText(eMsk));
                        }
                    }
                }
                // Apply text source document / styling
                if (lspec.textGroup && newLayer instanceof TextLayer) {
                    AE.applyPropertyGroup(newLayer.property("Text"), lspec.textGroup, warn);
                }
                // Shape layer contents — recursively recreate shape groups
                if (lspec.contentsGroup && newLayer instanceof ShapeLayer) {
                    try {
                        var contentsRoot = newLayer.property("Contents");
                        AE.importShapeContents(contentsRoot, lspec.contentsGroup, warn);
                    } catch (eShape) {
                        warn("shape contents import failed for '" + lspec.name + "': " + AE.errText(eShape));
                    }
                }
                // Time Remap — must be enabled BEFORE applying keyframes
                if (lspec.timeRemapEnabled && newLayer instanceof AVLayer) {
                    try {
                        newLayer.timeRemapEnabled = true;
                        if (lspec.timeRemapProperty) {
                            AE.applyPropertyValue(newLayer.property("Time Remap"), lspec.timeRemapProperty);
                        }
                    } catch (eTr) {
                        warn("time remap restore failed for '" + lspec.name + "': " + AE.errText(eTr));
                    }
                }
                // Material Options (3D layers)
                if (lspec.materialOptionsGroup && newLayer instanceof AVLayer && newLayer.threeDLayer) {
                    try {
                        AE.applyPropertyGroup(newLayer.property("Material Options"), lspec.materialOptionsGroup, warn);
                    } catch (eMat) { /* ignore */ }
                }
                // Audio
                if (lspec.audioGroup && newLayer instanceof AVLayer) {
                    try {
                        AE.applyPropertyGroup(newLayer.property("Audio"), lspec.audioGroup, warn);
                    } catch (eAud) { /* ignore */ }
                }
                // Layer markers
                if (lspec.markers) {
                    try {
                        AE.applyPropertyValue(newLayer.property("Marker"), lspec.markers);
                    } catch (eLm) { warn("layer markers failed for '" + lspec.name + "': " + AE.errText(eLm)); }
                }
            } catch (eLayer) {
                warn("failed to create layer '" + (lspec.name || "?") + "' in comp '" + spec.name + "': " + AE.errText(eLayer));
            }
        }
    }

    // --- Pass 5: parentFolder assignment (items) ---
    for (i = 0; i < items.length; i++) {
        var spc = items[i];
        if (spc.parentFolderId == null) continue;
        var tgt = remap[String(spc.id)];
        var par = remap[String(spc.parentFolderId)];
        if (tgt && par && par instanceof FolderItem) {
            try { tgt.parentFolder = par; } catch (ePF) { warn("failed to set parentFolder on '" + spc.name + "': " + AE.errText(ePF)); }
        }
    }

    // --- Pass 6: layer parenting (within each comp) ---
    for (cb = 0; cb < compBindings.length; cb++) {
        var b2 = compBindings[cb];
        var compDst2 = b2.comp;
        var spec2 = b2.spec;
        if (!spec2.layers) continue;
        // Layers in the spec are in top-down order (index 1 first). After the
        // reverse-add pass above, the comp contains layers in the same order.
        for (var lk = 0; lk < spec2.layers.length; lk++) {
            var ls = spec2.layers[lk];
            if (ls.parentIndex == null) continue;
            try {
                var child = compDst2.layer(ls.index);
                var parent = compDst2.layer(ls.parentIndex);
                if (child && parent) child.parent = parent;
            } catch (eP) {
                warn("failed to set parent for layer index " + ls.index + " in comp '" + spec2.name + "': " + AE.errText(eP));
            }
        }
    }

    // Build a remap summary that's safe to serialize (just ids, not Item refs)
    var remapOut = {};
    for (var k in remap) {
        if (remap.hasOwnProperty(k) && remap[k]) {
            remapOut[k] = remap[k].id;
        }
    }

    return {
        ok: true,
        itemCount: items.length,
        createdCount: (function () {
            var n = 0;
            for (var kk in remap) { if (remap.hasOwnProperty(kk) && remap[kk]) n++; }
            return n;
        })(),
        remap: remapOut,
        warnings: warnings,
        logs: logs
    };
};

// Recreate the Contents of a Shape layer. Unlike Effects (which use addProperty
// with an effect matchName directly on the Effects group), shape contents use
// a fixed set of matchNames like "ADBE Vector Group", "ADBE Vector Shape - Rect",
// "ADBE Vector Graphic - Stroke", etc. We walk the exported group spec and
// recursively addProperty for each sub-group on the target.
AE.importShapeContents = function (target, spec, warn) {
    if (!target || !spec) return;
    // Leaf properties directly on this group
    if (spec.properties) {
        for (var pi = 0; pi < spec.properties.length; pi++) {
            var ps = spec.properties[pi];
            var prop = null;
            try { prop = target.property(ps.matchName); } catch (e1) {}
            if (!prop) { try { prop = target.property(ps.name); } catch (e2) {} }
            if (!prop) continue;
            try { AE.applyPropertyValue(prop, ps); } catch (eAp) { if (warn) warn("shape property '" + ps.name + "': " + AE.errText(eAp)); }
        }
    }
    // Sub-groups: add them via addProperty with matchName, then recurse
    if (spec.groups) {
        for (var gi = 0; gi < spec.groups.length; gi++) {
            var gs = spec.groups[gi];
            // Try to find an existing subgroup (shapes pre-populate certain
            // groups like "Transform" on Vector Groups). If missing, addProperty.
            var sub = null;
            try { sub = target.property(gs.matchName); } catch (eSub1) {}
            if (!sub) {
                try { sub = target.addProperty(gs.matchName); } catch (eAdd) {
                    if (warn) warn("could not add shape group " + gs.matchName + ": " + AE.errText(eAdd));
                    continue;
                }
            }
            if (sub) {
                if (gs.name && sub.name !== gs.name) { try { sub.name = gs.name; } catch (eNm) {} }
                AE.importShapeContents(sub, gs, warn);
            }
        }
    }
};

// Apply a serialized PropertyGroup (from helpers.serializePropertyGroup) onto
// a live PropertyGroup, matching by matchName where possible and falling back
// to name.
AE.applyPropertyGroup = function (target, spec, warn) {
    if (!target || !spec) return;
    // Leaf properties
    if (spec.properties) {
        for (var i = 0; i < spec.properties.length; i++) {
            var pspec = spec.properties[i];
            var prop = null;
            try { prop = target.property(pspec.matchName); } catch (e1) {}
            if (!prop) {
                try { prop = target.property(pspec.name); } catch (e2) {}
            }
            if (!prop) {
                // Some properties (like Separate Dimensions placeholders) may not exist on all layer types
                continue;
            }
            try { AE.applyPropertyValue(prop, pspec); }
            catch (eAp) { if (warn) warn("failed to apply property '" + pspec.name + "': " + AE.errText(eAp)); }
        }
    }
    // Nested groups — only recurse if the matching subgroup already exists
    // on the target (we don't auto-add, because effects/masks are handled
    // by the import pass before calling applyPropertyGroup).
    if (spec.groups) {
        for (var g = 0; g < spec.groups.length; g++) {
            var gspec = spec.groups[g];
            var sub = null;
            try { sub = target.property(gspec.matchName); } catch (e3) {}
            if (!sub) { try { sub = target.property(gspec.name); } catch (e4) {} }
            if (sub) AE.applyPropertyGroup(sub, gspec, warn);
        }
    }
};

// Convert a serialized value (possibly a __kind tagged object) back to a
// native ExtendScript value suitable for prop.setValue / keyframe apply.
AE.unwrapValue = function (val, existingTemplate) {
    if (val === null || val === undefined) return val;
    if (val.__kind === "TextDocument") {
        // Mutate an existing TextDocument (required because AE rejects
        // vanilla constructed documents in some cases).
        var tmpl = existingTemplate || null;
        if (!tmpl) tmpl = new TextDocument(val.text || "");
        if (val.text !== undefined) { try { tmpl.text = val.text; } catch (e) {} }
        if (val.font) { try { tmpl.font = val.font; } catch (e) {} }
        if (val.fontSize) { try { tmpl.fontSize = val.fontSize; } catch (e) {} }
        if (val.fillColor) { try { tmpl.fillColor = val.fillColor; } catch (e) {} }
        if (val.strokeColor) { try { tmpl.strokeColor = val.strokeColor; } catch (e) {} }
        if (val.strokeWidth !== undefined) { try { tmpl.strokeWidth = val.strokeWidth; } catch (e) {} }
        if (val.tracking !== undefined) { try { tmpl.tracking = val.tracking; } catch (e) {} }
        if (val.leading !== undefined) { try { tmpl.leading = val.leading; } catch (e) {} }
        if (val.baselineShift !== undefined) { try { tmpl.baselineShift = val.baselineShift; } catch (e) {} }
        if (val.applyFill !== undefined) { try { tmpl.applyFill = val.applyFill; } catch (e) {} }
        if (val.applyStroke !== undefined) { try { tmpl.applyStroke = val.applyStroke; } catch (e) {} }
        // Box text restoration only applies if we have size data
        if (val.boxText && val.boxTextSize) {
            try { tmpl.boxTextSize = val.boxTextSize; } catch (e) {}
            if (val.boxTextPos) { try { tmpl.boxTextPos = val.boxTextPos; } catch (e) {} }
        }
        return tmpl;
    }
    if (val.__kind === "Shape") {
        var sh = new Shape();
        sh.closed = !!val.closed;
        if (val.vertices) sh.vertices = val.vertices;
        if (val.inTangents) sh.inTangents = val.inTangents;
        if (val.outTangents) sh.outTangents = val.outTangents;
        return sh;
    }
    if (val.__kind === "MarkerValue") {
        var mv = new MarkerValue(val.comment || "");
        if (val.chapter) { try { mv.chapter = val.chapter; } catch (e) {} }
        if (val.url) { try { mv.url = val.url; } catch (e) {} }
        if (val.frameTarget) { try { mv.frameTarget = val.frameTarget; } catch (e) {} }
        if (val.cuePointName) { try { mv.cuePointName = val.cuePointName; } catch (e) {} }
        if (val.duration !== undefined) { try { mv.duration = val.duration; } catch (e) {} }
        if (val.label !== undefined) { try { mv.label = val.label; } catch (e) {} }
        if (val.protectedRegion !== undefined) { try { mv.protectedRegion = val.protectedRegion; } catch (e) {} }
        return mv;
    }
    return val;
};

AE.applyPropertyValue = function (prop, pspec) {
    var val = pspec.value;
    if (val !== null && val !== undefined) {
        var unwrapped = AE.unwrapValue(val, (val.__kind === "TextDocument") ? AE.safeGet(function () { return prop.value; }, null) : null);
        if (unwrapped !== null && unwrapped !== undefined) {
            try { prop.setValue(unwrapped); } catch (eSv) { /* some props are read-only; swallow */ }
        }
    }
    // Keyframes
    if (pspec.keyframes && pspec.keyframes.length > 0) {
        // Clear existing keys first
        while (prop.numKeys > 0) { try { prop.removeKey(1); } catch (eRk) { break; } }
        var times = [];
        var values = [];
        for (var k = 0; k < pspec.keyframes.length; k++) {
            var kf = pspec.keyframes[k];
            var kv = AE.unwrapValue(kf.value, (kf.value && kf.value.__kind === "TextDocument") ? AE.safeGet(function () { return prop.value; }, null) : null);
            times.push(kf.time);
            values.push(kv);
        }
        // Marker-valued keyframes must be set one at a time — setValuesAtTimes
        // doesn't accept MarkerValue arrays.
        var isMarker = (pspec.keyframes[0].value && pspec.keyframes[0].value.__kind === "MarkerValue");
        if (isMarker) {
            for (var km = 0; km < times.length; km++) {
                try { prop.setValueAtTime(times[km], values[km]); } catch (ePm) { /* ignore */ }
            }
        } else {
            try {
                prop.setValuesAtTimes(times, values);
            } catch (eKf) {
                // Fallback: per-key
                for (var kk = 0; kk < times.length; kk++) {
                    try { prop.setValueAtTime(times[kk], values[kk]); } catch (ePk) {}
                }
            }
        }
        // Apply interpolation types (spatial vs temporal handled by setInterpolationTypeAtKey's two-arg form)
        for (var ki = 0; ki < pspec.keyframes.length; ki++) {
            var kfI = pspec.keyframes[ki];
            if (kfI.inInterp != null && kfI.outInterp != null) {
                try { prop.setInterpolationTypeAtKey(ki + 1, kfI.inInterp, kfI.outInterp); } catch (eI) {}
            }
        }
    }
    // Expression
    if (pspec.expression && prop.canSetExpression) {
        try { prop.expression = pspec.expression; prop.expressionEnabled = true; } catch (eEx) {}
    }
};


(function dispatcherEntry() {
    // --- Talking about exceptions safely -----------------------------------
    // `"failed: " + e` is not a safe way to report an error in ExtendScript.
    // The engine cannot coerce an Error to a primitive, so the concatenation
    // ITSELF throws ("Object of type Error found where a Number, Array, or
    // Property is needed") — from inside the handler whose whole job was to
    // report the original failure. The real error is lost, the replacement
    // escapes, and AE raises a modal that blocks all scripting until a human
    // clicks OK; every later call then fails as a busy-lock timeout.
    //
    // So: nothing in this file interpolates an exception directly. Everything
    // goes through these two. helpers.jsx exposes the same formatter as
    // AE.errText for generated code; the dispatcher keeps its own copy so it
    // remains able to report failures even if an #include did not take.
    function describeError(e) {
        try {
            if (e === null || e === undefined) return "unknown error";
            if (typeof e === "string") return e;
            var msg = (e.message === undefined || e.message === null) ? "" : String(e.message);
            if (msg.length === 0) msg = "error";
            if (e.line !== undefined && e.line !== null) msg += " (line " + String(e.line) + ")";
            return msg;
        } catch (eFmt) {
            return "unformattable error";
        }
    }

    function errStack(e) {
        try {
            return (e && e.stack) ? String(e.stack) : null;
        } catch (eSt) {
            return null;
        }
    }

    // Published as soon as the mailbox is known so the top-level guard has
    // somewhere to write if anything below it dies.
    var fatalLogPath = null;

    function dispatcherMain() {
        var REQUEST_PREFIX = "request-";
        var REQUEST_SUFFIX = ".json";

        function normalizePath(p) {
            return String(p).replace(/\\/g, "/");
        }

        // --- Locate the mailbox --------------------------------------------
        // SECURITY: whatever directory we pick, we execute the `code` string of
        // a request found there. There is no signature to check — the mailbox
        // IS the trust boundary, and the capability policy (AE_MCP_READONLY,
        // AE_MCP_ENABLE_EVAL, category allowlist) lives entirely on the Node
        // side and cannot help here. So the list of places we are willing to
        // read from is kept as short as it can be:
        //
        //   0. $.global.AE_MCP_RUNTIME_DIR_OVERRIDE — set by the macOS
        //      launcher's DoScript bootstrap, which (unlike `-r`) can pass data
        //      in. It names the exact mailbox of the server that launched THIS
        //      run. When it is present it is used ALONE: falling back would mean
        //      executing a request some other party left somewhere else.
        //   1. AE_MCP_RUNTIME_DIR, published by Node as a pointer file (the env
        //      var itself is invisible to us: `-r` is delivered to the
        //      already-running AE process, whose environment is not the
        //      spawner's).
        //   2. <temp>/kerry-after-effects-mcp/runtime — the default both sides compute.
        //
        // The in-package location (<script>/../runtime) is deliberately NOT a
        // candidate: an install directory is far more likely to be writable by
        // other users than a per-user temp dir.
        function candidateRuntimeDirs() {
            var dirs = [];
            try {
                var injected = $.global.AE_MCP_RUNTIME_DIR_OVERRIDE;
                if (injected) {
                    // Authoritative and exclusive — see above.
                    return [normalizePath(String(injected))];
                }
            } catch (eInjected) { /* not injected — a Windows `-r` launch */ }
            var tempRoot = null;
            try {
                tempRoot = normalizePath(Folder.temp.fsName) + "/kerry-after-effects-mcp";
            } catch (eTemp) { /* no temp folder — nothing we are willing to read */ }

            if (tempRoot !== null) {
                try {
                    var pointer = new File(tempRoot + "/runtime-dir.txt");
                    if (pointer.exists) {
                        pointer.encoding = "UTF-8";
                        if (pointer.open("r")) {
                            var pointed = pointer.read();
                            pointer.close();
                            if (pointed) {
                                pointed = normalizePath(pointed).replace(/^\s+|\s+$/g, "");
                                if (pointed.length > 0) dirs.push(pointed);
                            }
                        }
                    }
                } catch (ePtr) { /* unreadable pointer — use the default below */ }
                dirs.push(tempRoot + "/runtime");
            }

            return dirs;
        }

        /** Oldest pending request in `dir`, or null. Oldest-first keeps a backlog fair. */
        function oldestRequestIn(dir) {
            try {
                var folder = new Folder(dir);
                if (!folder.exists) return null;
                var files = folder.getFiles(REQUEST_PREFIX + "*" + REQUEST_SUFFIX);
                if (!files || files.length === 0) return null;
                var best = null;
                for (var i = 0; i < files.length; i++) {
                    var f = files[i];
                    if (!(f instanceof File)) continue;
                    if (best === null) { best = f; continue; }
                    try {
                        if (f.modified < best.modified) best = f;
                    } catch (eCmp) { /* unstat-able; keep the incumbent */ }
                }
                return best;
            } catch (eScan) {
                return null;
            }
        }

        var runtimeDir = null;
        var requestFile = null;
        var candidates = candidateRuntimeDirs();
        for (var ci = 0; ci < candidates.length; ci++) {
            var found = oldestRequestIn(candidates[ci]);
            if (found !== null) {
                runtimeDir = candidates[ci];
                requestFile = found;
                break;
            }
        }

        if (requestFile === null) {
            // Nothing pending: normally this means another dispatcher run
            // (spawned earlier, executed late by AE) already consumed the
            // request and will write the response — so exit WITHOUT writing
            // anything, or we would clobber it. It can ALSO mean the two sides
            // disagree about where the mailbox is (e.g. AE running as a
            // different user, so a different Folder.temp). Leave a breadcrumb
            // listing what we searched: the Node side can only report a bare
            // timeout for that case.
            try {
                var diagDir = candidates.length > 0 ? candidates[candidates.length - 1] : null;
                for (var di = 0; di < candidates.length; di++) {
                    if (new Folder(candidates[di]).exists) { diagDir = candidates[di]; break; }
                }
                if (diagDir !== null) {
                    var diag = new File(diagDir + "/dispatcher.log");
                    diag.encoding = "UTF-8";
                    if (diag.open("a")) {
                        diag.writeln("[" + new Date().toString() + "] no pending request; searched: " + candidates.join(" | "));
                        diag.close();
                    }
                }
            } catch (eDiag) { /* ignore */ }
            return;
        }

        var logPath = runtimeDir + "/dispatcher.log";
        fatalLogPath = logPath;

        function appendLog(msg) {
            // Fire-and-forget log; swallow errors so logging never breaks dispatch.
            try {
                var lf = new File(logPath);
                lf.encoding = "UTF-8";
                lf.open("a");
                lf.writeln("[" + new Date().toString() + "] " + msg);
                lf.close();
            } catch (e) { /* ignore */ }
        }

        // Top-of-dispatcher marker — proves we reached this point even if later
        // steps fail. Always attempted; errors silenced.
        try {
            var startMarker = new File(runtimeDir + "/dispatcher_start.txt");
            startMarker.encoding = "UTF-8";
            startMarker.open("w");
            startMarker.write("start:" + new Date().toString() + " version:" + app.version + " numItems:" + app.project.numItems);
            startMarker.close();
        } catch (eMark) { /* ignore */ }

        // --- Identify the request from its filename ------------------------
        // Filename is authoritative: a request whose JSON body we cannot parse
        // still gets a correlated response instead of stranding the caller.
        var requestName = String(requestFile.name);
        try { requestName = decodeURI(requestName); } catch (eDec) { /* keep raw */ }
        var requestId = requestName.substring(
            REQUEST_PREFIX.length,
            requestName.length - REQUEST_SUFFIX.length
        );

        var response = {
            id: requestId,
            ok: false,
            phase: "dispatch",
            result: null,
            error: null,
            stack: null,
            logs: []
        };

        var responsePath = runtimeDir + "/response-" + requestId + ".json";
        var tmpName = ".response-" + requestId + ".json.tmp";
        var tmpPath = runtimeDir + "/" + tmpName;

        /** Move the freshly written tmp file into place, replacing any stale answer. */
        function promoteTmp(tmp) {
            var dest = new File(responsePath);
            if (dest.exists) {
                try { dest.remove(); } catch (eRm) { /* ignore */ }
            }
            // File#rename takes a new name (not a path). tmp and dest share a
            // parent dir, so this is effectively atomic on NTFS — the poller
            // never sees a half-written response.
            tmp.rename("response-" + requestId + ".json");
        }

        /**
         * Strip `s` to the printable-ASCII characters that need no JSON escaping.
         * Only used by the fallback below, which has to build its JSON by hand
         * precisely because JSON.stringify is what just failed.
         */
        function jsonSafeAscii(s) {
            var t = String(s);
            var out = "";
            for (var i = 0; i < t.length; i++) {
                var c = t.charAt(i);
                var code = t.charCodeAt(i);
                out += (code >= 0x20 && code < 0x7f && c !== "\"" && c !== "\\") ? c : " ";
            }
            return out;
        }

        /**
         * Last resort when serializing the real response fails. Hand-builds a
         * minimal, provably well-formed error response so the caller learns
         * what happened immediately instead of waiting out its 60s timeout —
         * which is the only thing it could do if we wrote nothing at all.
         */
        function writeFallbackResponse(why) {
            try {
                var phase = (response.phase === "execute") ? "execute" : "dispatch";
                var body = "{\"id\":\"" + jsonSafeAscii(requestId)
                    + "\",\"ok\":false,\"phase\":\"" + phase
                    + "\",\"result\":null,\"error\":\"" + jsonSafeAscii("could not serialize response: " + why)
                    + "\",\"stack\":null,\"logs\":[]}";
                var tmp = new File(tmpPath);
                tmp.encoding = "UTF-8";
                if (!tmp.open("w")) return;
                tmp.write(body);
                tmp.close();
                promoteTmp(tmp);
            } catch (eFb) { /* nothing left to try; the caller will time out */ }
        }

        function writeResponse() {
            try {
                var tmp = new File(tmpPath);
                tmp.encoding = "UTF-8";
                if (!tmp.open("w")) {
                    appendLog("FATAL: cannot open tmp response for write: " + tmp.error);
                    return;
                }
                tmp.write(JSON.stringify(response));
                tmp.close();
                promoteTmp(tmp);
            } catch (e) {
                var why = describeError(e);
                appendLog("FATAL: writeResponse threw: " + why);
                writeFallbackResponse(why);
            }
        }

        // --- Read request (consume-on-read) --------------------------------
        var request = null;
        try {
            requestFile.encoding = "UTF-8";
            if (!requestFile.open("r")) {
                response.error = "cannot open " + requestName + ": " + requestFile.error;
                writeResponse();
                return;
            }
            var raw = requestFile.read();
            requestFile.close();
            // Consume so no other queued dispatcher run can re-execute it. If the
            // delete fails we proceed anyway (degrades to the old behavior).
            try {
                if (!requestFile.remove()) appendLog("WARN: could not consume " + requestName);
            } catch (eRm2) {
                appendLog("WARN: consuming " + requestName + " threw: " + describeError(eRm2));
            }
            request = JSON.parse(raw);
        } catch (eReq) {
            response.error = "failed to read request: " + describeError(eReq);
            response.stack = errStack(eReq);
            writeResponse();
            return;
        }

        if (!request || typeof request.code !== "string") {
            response.error = "request missing `code` field";
            writeResponse();
            return;
        }
        if (request.id && String(request.id) !== requestId) {
            // Body and filename disagree — refuse rather than answer under an id
            // the caller is not polling for.
            response.error = "request id mismatch: filename says " + requestId + ", body says " + String(request.id);
            writeResponse();
            return;
        }

        // --- Execute user code, normally inside an undo group --------------
        // `undoGroup: false` marks a request that DRIVES the undo stack (Undo,
        // Redo). AE resolves those against the group that is still open, so
        // wrapping them reverts nothing the caller asked for and leaves the
        // stack describing a step that never happened — such a request runs
        // bare. A missing field means the old contract: group it.
        var undoLabel = "mcp-aftereffects: " + (request.label || "action");
        var wantUndoGroup = (request.undoGroup !== false);
        // Dialog suppression is its OWN request field, not the undo-group
        // condition: project boundary requests (project.open / project.new)
        // run ungrouped yet are exactly the calls most likely to pop a modal
        // (missing footage/fonts on open). Only requests that DRIVE the undo
        // stack — Undo/Redo — must stay unsuppressed: beginSuppressDialogs
        // opens an undo-transaction-like scope of its own, so wrapping them
        // makes AE resolve Undo against THAT scope (nothing reverts, the
        // stack pops unbalanced, "UndoGroup Mismatch" warnings, broken redo).
        // A missing field means the old contract: suppress when grouping.
        var wantSuppress = (typeof request.suppressDialogs === "boolean") ? request.suppressDialogs : wantUndoGroup;
        var undoOpen = false;
        var dialogsSuppressed = false;
        response.phase = "execute";
        try {
            if (wantSuppress) {
                // Suppress modal alerts for the duration of the request.
                // try/catch inside the executed code cannot stop everything:
                // project.open on an AEP with missing footage/fonts, or an
                // effect raising its own warning, pops a modal that blocks
                // every later `-r` launch until a human clicks OK. MUST be
                // undone in the finally below — left on, it would silently
                // eat dialogs for the user's whole session.
                try {
                    app.beginSuppressDialogs();
                    dialogsSuppressed = true;
                } catch (eSup) { /* unavailable — run with dialogs enabled */ }
            }

            if (wantUndoGroup) {
                app.beginUndoGroup(undoLabel);
                undoOpen = true;
            }

            // User code is a function body. Convention: `return <JSON-serializable>;`
            // `log(msg)` pushes breadcrumbs into response.logs; `payload` carries
            // bulk data that was NOT inlined into the source (see EvalRequest).
            var logs = response.logs;
            var fn = new Function(
                "app", "log", "payload",
                request.code
            );
            var result = fn(
                app,
                function (msg) { logs.push(String(msg)); },
                (typeof request.payload === "undefined") ? null : request.payload
            );

            response.result = (typeof result === "undefined") ? null : result;
            response.ok = true;
        } catch (eExec) {
            response.ok = false;
            response.error = describeError(eExec);
            response.stack = errStack(eExec);
        } finally {
            if (undoOpen) {
                try { app.endUndoGroup(); } catch (eEnd) { /* ignore */ }
            }
            if (dialogsSuppressed) {
                // false: do NOT replay the suppressed alerts — that replay is
                // itself a modal, the exact thing being prevented. Whatever was
                // suppressed is already reported through response.error/logs.
                try { app.endSuppressDialogs(false); } catch (eEndSup) { /* ignore */ }
            }
        }

        writeResponse();
    }

    // --- Top-level guard ---------------------------------------------------
    // Nothing may escape from here into AE's modal error dialog. A modal blocks
    // every subsequent `-r` launch for the rest of the session, which the Node
    // side can only observe as call after call timing out on the busy lock — a
    // symptom that says nothing about the cause. Losing a log line is the
    // cheaper failure, so this catch swallows.
    try {
        dispatcherMain();
    } catch (eTop) {
        try {
            if (fatalLogPath !== null) {
                var fatalLog = new File(fatalLogPath);
                fatalLog.encoding = "UTF-8";
                if (fatalLog.open("a")) {
                    fatalLog.writeln("[" + new Date().toString() + "] FATAL: dispatcher threw: " + describeError(eTop));
                    fatalLog.close();
                }
            }
        } catch (eSilent) { /* deliberately silent — see above */ }
    }
})();
