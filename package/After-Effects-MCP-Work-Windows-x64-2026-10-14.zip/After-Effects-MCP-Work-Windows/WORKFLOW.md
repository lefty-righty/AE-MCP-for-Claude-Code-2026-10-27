# Operating the standalone After Effects MCP

## Scope and evidence

This MCP is a general local AE connector with eight tools and on-demand operations. The successful prior punch was planned and executed by Codex through these operations; the MCP itself does not contain a campaign-specific planning engine. Use the active job brief to determine allowed changes. Do not execute archived job scripts against a new campaign or reuse another project's item IDs.

At session start, read the AE version and project. Discover category schemas through `ae_catalog` before using `ae_do`. Use numeric IDs from the current project. Parse returned `isError`, top-level `ok`, and nested operation results. A server handshake, queued script, or plausible completion statement does not establish a successful edit.

The eight tools are `ae_version_info`, `ae_project_info`, `ae_comp_info`, `ae_layer_info`, `ae_render_frame`, `ae_save_project`, `ae_catalog`, and `ae_do`. Read-only mode withholds `ae_save_project` and rejects modifying operations; rendering a requested inspection frame can still write a PNG. The supplied live verifier does not request frames or any other render.

## Punch intake and preflight

Record source AEP, intended master comps, approved script/offer text, replacement media/VO paths, required duration, versioned destination AEP, output folder, delivery specification and whether legal copy is manual or supplied. Do not manufacture missing terms. Inspect project save/dirty state, missing footage, fonts/effects, expressions, nested/repeated offer comps, styled text, render queue and source relationships. Existing unsaved work must be preserved.

Explain the change plan and any unresolved conflict before committing edits when the brief requires that gate. Installation alone is not a creative-edit authorization. Once an edit is authorized, save a separate versioned AEP and preserve the original. Duplicate nested comps that must change only for the new version; account for repeated offer appearances without altering shared unrelated campaigns.

## Editing

Use declared operations with validated parameters. Preserve typography, per-character styling, campaign art, logo, end tag and approved legal exposure. Text replacement can flatten styling or interact with expressions; inspect first and use range-aware operations when needed. For source replacement, review `fixExpressions` and explicitly disable automatic expression rewriting unless it is intended.

Map new VO timing to each offer, including repeats. Adjust only sections designated movable or extendable. Preserve required commercial duration and never silently accelerate narration. Keep replacement artwork proportions/crops appropriate to the template. Import new media into the existing campaign without relocating its disk sources.

Follow `skills/after-effects-project-organize/SKILL.md`. New working items use Assets/Audios/VO, Assets/Audios/Music, Assets/Images, Assets/Footages, Comps and Solids. Imported projects/template packages remain together under Assets/AEPs/<source project>, with their hierarchy intact. A punch does not implicitly authorize whole-project cleanup.

Every call is automatically undo-grouped when appropriate. Never add manual undo groups around generated code. A batch is not a transaction: a failure can leave earlier operations applied. Inspect partial results and current state before any retry. On a timeout, stop; the AE script may still be running.

## Verification and delivery

Read back edited text, media paths, composition duration/frame rate, layer timings, expression errors and repeated offer sections. Inspect representative frames against the original campaign and listen to the VO against the timeline. Check the actual saved AEP path. State remaining manual work precisely.

Render only when the user requests it. Inspect and isolate the intended render-queue item because render.start can process the queue. Export into the job's specified output folder. Verify the actual codec (including ProRes 4444 when requested), dimensions, frame rate, duration and audio before calling a delivery ready. Human approval precedes client delivery during initial testing. No automated render/export test was added to the installer.

## First work validation

Start with a duplicate campaign and one offer/VO update. Establish read-only connectivity before edits. Compare a before/after item inventory and confirm source preservation, typography, repeated offers, legal placement, timing and saved version. Report measured observations and unresolved issues; do not generalize one successful punch to every campaign.
