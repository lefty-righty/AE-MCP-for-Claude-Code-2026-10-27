$ErrorActionPreference = 'Stop'
& (Join-Path $PSScriptRoot 'runtime\node.exe') (Join-Path $PSScriptRoot 'scripts\rebuild.mjs')
if ($LASTEXITCODE -ne 0) { throw 'Rebuild failed.' }
