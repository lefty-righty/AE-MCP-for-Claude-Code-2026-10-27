// Compatibility entry point for existing registrations.
import "./server.mjs";
