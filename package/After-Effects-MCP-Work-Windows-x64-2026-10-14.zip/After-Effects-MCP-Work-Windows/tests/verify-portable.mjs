import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {Client} from '../upstream/node_modules/@modelcontextprotocol/sdk/dist/esm/client/index.js';
import {StdioClientTransport} from '../upstream/node_modules/@modelcontextprotocol/sdk/dist/esm/client/stdio.js';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const live = process.argv.includes('--live');
const i = process.argv.indexOf('--report');
const reportPath = i >= 0 ? path.resolve(process.argv[i + 1]) : path.join(root, 'logs', live ? 'portable-live.json' : 'portable-offline.json');
const report = {startedAt: new Date().toISOString(), node: process.version, live, cases: [], ok: false};
const expected = ['ae_project_info', 'ae_comp_info', 'ae_layer_info', 'ae_render_frame', 'ae_save_project', 'ae_version_info', 'ae_catalog', 'ae_do'].sort();
const decode = r => r.structuredContent ?? JSON.parse(r.content.find(c => c.type === 'text').text);
try {
  if (live) {
    const settings = path.join(root, 'installation.json');
    if (fs.existsSync(settings)) {
      const installed = JSON.parse(fs.readFileSync(settings, 'utf8'));
      process.env.AE_MCP_EXE = installed.afterEffectsExe;
      process.env.AE_MCP_DISPATCHER = installed.dispatcher;
    }
    assert.ok(process.env.AE_MCP_EXE && fs.existsSync(process.env.AE_MCP_EXE), 'AE_MCP_EXE must point at AfterFX.exe.');
    assert.ok(process.env.AE_MCP_DISPATCHER && fs.existsSync(process.env.AE_MCP_DISPATCHER), 'Install the dispatcher first.');
    const processJson = execFileSync('powershell.exe', ['-NoProfile', '-Command', `@(Get-CimInstance Win32_Process -Filter "Name='AfterFX.exe'" | Select-Object -ExpandProperty ExecutablePath) | ConvertTo-Json -Compress`], {encoding: 'utf8', windowsHide: true}).trim();
    const parsedProcesses = processJson ? JSON.parse(processJson) : [];
    const processes = Array.isArray(parsedProcesses) ? parsedProcesses : [parsedProcesses];
    assert.ok(processes.some(p => p && path.resolve(p).toLowerCase() === path.resolve(process.env.AE_MCP_EXE).toLowerCase()), 'Open the installed AE_MCP_EXE version of After Effects yourself first. No matching readable AE process is running; this verifier will not launch a different version.');
    assert.equal(fs.readFileSync(process.env.AE_MCP_DISPATCHER).equals(fs.readFileSync(path.join(root, 'dispatcher.jsx'))), true, 'Deployed dispatcher differs from this package.');
  }
  for (const readOnly of (live ? [true] : [false, true])) {
    const temp = live ? null : fs.mkdtempSync(path.join(os.tmpdir(), 'ae-mcp-package-check-'));
    const env = {...process.env, AE_MCP_READONLY: readOnly ? '1' : '0', AE_MCP_ENABLE_EVAL: '0', AE_MCP_ALLOW_CATEGORIES: '', AE_MCP_RUNTIME_DIR: ''};
    if (temp) { env.TEMP = temp; env.TMP = temp; env.TMPDIR = temp; }
    let stderr = '';
    const transport = new StdioClientTransport({command: process.execPath, args: [path.join(root, 'server.mjs')], cwd: root, env, stderr: 'pipe'});
    const client = new Client({name: 'local-ae-verifier', version: 'portable-1.0.0'});
    const check = {readOnly, live};
    try {
      const started = Date.now();
      const pending = client.connect(transport);
      transport.stderr?.on('data', d => { stderr += d; });
      await pending;
      const list = await client.listTools();
      assert.deepEqual(list.tools.map(t => t.name).sort(), expected.filter(n => !readOnly || n !== 'ae_save_project'));
      check.handshakeMs = Date.now() - started;
      check.tools = list.tools.map(t => t.name);
      check.schemaSha256 = crypto.createHash('sha256').update(JSON.stringify(list)).digest('hex');
      const catalog = await client.callTool({name: 'ae_catalog', arguments: {}});
      assert.ok(!catalog.isError);
      const inventory = decode(catalog);
      check.totalOperations = inventory.totalOperations;
      check.operations = inventory.categories.flatMap(c => c.operations).sort();
      check.policy = inventory.policy;
      assert.ok(check.totalOperations > 0);
      assert.ok(!check.operations.includes('eval.run'));
      for (const category of ['text', 'layer', 'comp', 'project']) {
        const detail = await client.callTool({name: 'ae_catalog', arguments: {category}});
        assert.ok(!detail.isError, 'Catalog category ' + category);
      }
      const invalid = await client.callTool({name: 'ae_do', arguments: {operation: 'not.an.operation'}});
      assert.ok(invalid.isError, 'Unknown operation must be refused without AE dispatch');
      const forbidden = await client.callTool({name: 'ae_do', arguments: {operation: 'eval.run', args: {code: 'return 1;'}}});
      assert.ok(forbidden.isError, 'Arbitrary eval must be refused');
      if (readOnly) {
        const mutation = await client.callTool({name: 'ae_do', arguments: {operation: 'comp.create', args: {name: 'must-not-create', width: 1920, height: 1080, fps: 24, duration: 10}}});
        assert.ok(mutation.isError, 'Readonly must refuse mutations');
      }
      check.invalidOperationRejected = true;
      check.evalDisabled = true;
      check.readOnlyMutationRejected = readOnly;
      if (live) {
        const version = await client.callTool({name: 'ae_version_info', arguments: {}}, undefined, {timeout: 30000});
        assert.ok(!version.isError, JSON.stringify(version));
        const project = await client.callTool({name: 'ae_project_info', arguments: {}}, undefined, {timeout: 30000});
        assert.ok(!project.isError, JSON.stringify(project));
        const v = decode(version), p = decode(project);
        assert.ok(v.ok && p.ok);
        assert.equal(p.result.numItems, v.result.project.numItems, 'Project changed during read-only test');
        assert.equal(p.result.file, v.result.project.file, 'Project file changed during read-only test');
        assert.equal(p.result.dirty, v.result.project.dirty, 'Dirty state changed during read-only test');
        check.version = v.result.app.version;
        check.project = {file: p.result.file, numItems: p.result.numItems, dirty: p.result.dirty};
        check.liveReadback = true;
      }
      check.ok = true;
    } finally { await client.close(); check.stderr = stderr; report.cases.push(check); }
  }
  report.ok = true;
} catch (error) { report.error = error.message; process.exitCode = 1; }
finally {
  fs.mkdirSync(path.dirname(reportPath), {recursive: true});
  fs.writeFileSync(reportPath, JSON.stringify(report, null, 2));
  console.log(JSON.stringify({...report, cases: report.cases.map(({operations, stderr, ...c}) => c), reportPath}, null, 2));
}
