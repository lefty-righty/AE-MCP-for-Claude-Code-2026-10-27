import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {Client} from '../upstream/node_modules/@modelcontextprotocol/sdk/dist/esm/client/index.js';
import {StdioClientTransport} from '../upstream/node_modules/@modelcontextprotocol/sdk/dist/esm/client/stdio.js';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const live=process.argv.includes('--live');
let stderr='';
const transport=new StdioClientTransport({command:process.execPath,args:[path.join(root,'server.mjs')],cwd:root,env:{...process.env,AE_MCP_READONLY:live?'1':'0'},stderr:'pipe'});
const client=new Client({name:'local-ae-verifier',version:'1.0.0'});
const started=Date.now();
const report={live,started:new Date().toISOString()};
try {
 await client.connect(transport);
 transport.stderr?.on('data',d=>stderr+=d);
 const list=await client.listTools();
 assert.equal(list.tools.length,live?7:8);
 report.handshakeMs=Date.now()-started;
 report.tools=list.tools.map(t=>t.name);
 report.toolSchemaCharacters=JSON.stringify(list).length;
 const catalog=await client.callTool({name:'ae_catalog',arguments:{}});
 assert.ok(!catalog.isError);
 report.catalog=true;
 const invalid=await client.callTool({name:'ae_do',arguments:{operation:'not.an.operation'}});
 assert.ok(invalid.isError);
 report.invalidOperationRejected=true;
 const forbidden=await client.callTool({name:'ae_do',arguments:{operation:'eval.run',args:{code:'return 1;'}}});
 assert.ok(forbidden.isError);
 report.evalDisabled=true;
 if(live){
  report.version=await client.callTool({name:'ae_version_info',arguments:{}},undefined,{timeout:120000});
  assert.ok(!report.version.isError,JSON.stringify(report.version));
  report.project=await client.callTool({name:'ae_project_info',arguments:{}},undefined,{timeout:120000});
  assert.ok(!report.project.isError,JSON.stringify(report.project));
 }
 report.ok=true;
} catch(e){report.ok=false;report.error=String(e);process.exitCode=1;}
finally {await client.close();report.stderr=stderr;writeFileSync(path.join(root,'logs',live?'verification-live.json':'verification-offline.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));}
